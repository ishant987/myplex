-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 09, 2026 at 06:11 AM
-- Server version: 10.11.14-MariaDB-log
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myplexus_dbx`
--

-- --------------------------------------------------------

--
-- Table structure for table `back_up_mpx_fund_dictionary`
--

DROP TABLE IF EXISTS `back_up_mpx_fund_dictionary`;
CREATE TABLE `back_up_mpx_fund_dictionary` (
  `fd_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `back_up_mpx_fund_type`
--

DROP TABLE IF EXISTS `back_up_mpx_fund_type`;
CREATE TABLE `back_up_mpx_fund_type` (
  `ft_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active_passive` enum('','A','P') DEFAULT NULL COMMENT 'A=Active,P=Passive',
  `monthly_performance` enum('','Y','N') DEFAULT NULL COMMENT 'Y=Yes,N=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `back_up_mpx_fund_watch`
--

DROP TABLE IF EXISTS `back_up_mpx_fund_watch`;
CREATE TABLE `back_up_mpx_fund_watch` (
  `fw_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `back_up_mpx_monthly_fund_house_performance`
--

DROP TABLE IF EXISTS `back_up_mpx_monthly_fund_house_performance`;
CREATE TABLE `back_up_mpx_monthly_fund_house_performance` (
  `mfhp_id` int(10) UNSIGNED NOT NULL,
  `dated` date NOT NULL,
  `fund_type_id` bigint(20) NOT NULL,
  `timespan` varchar(20) NOT NULL,
  `fund_code` varchar(50) NOT NULL,
  `cagr` decimal(10,2) DEFAULT NULL,
  `cagr_rank` int(11) DEFAULT NULL,
  `cagr_rank_improvement` int(11) DEFAULT NULL,
  `ret_less_idx` decimal(38,2) DEFAULT NULL,
  `ret_less_idx_rank` int(11) DEFAULT NULL,
  `ret_less_idx_rank_improvement` int(11) DEFAULT NULL,
  `jensen` decimal(38,2) DEFAULT NULL,
  `jensen_rank` int(11) DEFAULT NULL,
  `jensen_rank_improvement` int(11) DEFAULT NULL,
  `beta` decimal(38,2) DEFAULT NULL,
  `beta_rank` int(11) DEFAULT NULL,
  `beta_rank_improvement` int(11) DEFAULT NULL,
  `co_var` decimal(38,2) DEFAULT NULL,
  `co_var_rank` int(11) DEFAULT NULL,
  `co_var_rank_improvement` int(11) DEFAULT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `back_up_mpx_nfo_offer`
--

DROP TABLE IF EXISTS `back_up_mpx_nfo_offer`;
CREATE TABLE `back_up_mpx_nfo_offer` (
  `no_id` int(10) UNSIGNED NOT NULL,
  `type` enum('','f','l','t') NOT NULL COMMENT 'f=File,l=Link,t=Text',
  `fund_name` varchar(255) NOT NULL,
  `fund_opening` date NOT NULL,
  `fund_closing` date NOT NULL,
  `ft_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Fund / Scheme Type ID',
  `minimum_investment` varchar(128) DEFAULT NULL,
  `plan` varchar(128) DEFAULT NULL,
  `options` varchar(128) DEFAULT NULL,
  `entry_load` varchar(128) DEFAULT NULL,
  `exit_load` varchar(128) DEFAULT NULL,
  `thereafter` varchar(128) DEFAULT NULL,
  `objective` mediumtext DEFAULT NULL,
  `idc_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Indices / Benchmark ID',
  `fund_manager` varchar(128) DEFAULT NULL,
  `aa_col1_value` varchar(60) DEFAULT NULL,
  `aa_col1_text` varchar(60) DEFAULT NULL,
  `aa_col2_value` varchar(60) DEFAULT NULL,
  `aa_col2_text` varchar(60) DEFAULT NULL,
  `ces_row1_col1_text` varchar(255) DEFAULT NULL,
  `ces_row1_col2_text` varchar(60) DEFAULT NULL,
  `ces_row1_col3_text` varchar(60) DEFAULT NULL,
  `ces_row2_col1_text` varchar(255) DEFAULT NULL,
  `ces_row2_col2_text` varchar(60) DEFAULT NULL,
  `ces_row2_col3_text` varchar(60) DEFAULT NULL,
  `idea_distiller` mediumtext DEFAULT NULL,
  `fund_house_aaum` varchar(128) DEFAULT NULL,
  `fund_manager_experience` varchar(128) DEFAULT NULL,
  `uniqness` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `return` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `risk` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `operability` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `oomph_factor` mediumtext DEFAULT NULL,
  `media_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` date NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `cap_entry`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `cap_entry`;
CREATE TABLE `cap_entry` (
`scrip_name` varchar(150)
,`entry_date` date
,`market_cap` float
,`row_num` bigint(21)
,`cap_category` varchar(14)
);

-- --------------------------------------------------------

--
-- Table structure for table `final_ratio_data`
--

DROP TABLE IF EXISTS `final_ratio_data`;
CREATE TABLE `final_ratio_data` (
  `fund_code` varchar(25) DEFAULT NULL,
  `cagr_value` double DEFAULT NULL,
  `quartile` int(11) DEFAULT NULL,
  `decile` int(11) DEFAULT NULL,
  `median` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fund_temp`
--

DROP TABLE IF EXISTS `fund_temp`;
CREATE TABLE `fund_temp` (
  `FUNDTYPE` varchar(100) DEFAULT NULL,
  `CHANGEVAL` double DEFAULT NULL,
  `FundTypeID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fund_watch_disclaimer`
--

DROP TABLE IF EXISTS `fund_watch_disclaimer`;
CREATE TABLE `fund_watch_disclaimer` (
  `id` int(11) NOT NULL,
  `disclaimer` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_admin`
--

DROP TABLE IF EXISTS `mpx_admin`;
CREATE TABLE `mpx_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL COMMENT 'User Role ID',
  `username` varchar(30) NOT NULL,
  `password` varchar(64) NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `email` varchar(60) NOT NULL,
  `website` varchar(100) DEFAULT NULL,
  `secret` varchar(64) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_ask_expert_question`
--

DROP TABLE IF EXISTS `mpx_ask_expert_question`;
CREATE TABLE `mpx_ask_expert_question` (
  `aeq_id` int(10) UNSIGNED NOT NULL,
  `aet_id` int(10) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `image1` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `video_from` enum('','l','y') DEFAULT NULL COMMENT 'l=local,y=youtube',
  `video_data` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `u_id` bigint(20) DEFAULT NULL COMMENT 'User ID from users',
  `updated_id` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_ask_expert_question_answer`
--

DROP TABLE IF EXISTS `mpx_ask_expert_question_answer`;
CREATE TABLE `mpx_ask_expert_question_answer` (
  `aeqa_id` int(10) UNSIGNED NOT NULL,
  `aeq_id` int(10) NOT NULL,
  `aet_id` int(10) NOT NULL,
  `u_id` int(10) NOT NULL DEFAULT 0 COMMENT 'User ID (Expert ID)',
  `answer` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` enum('','a','u') DEFAULT NULL COMMENT 'a=admin,u=user',
  `updated_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_ask_expert_topic`
--

DROP TABLE IF EXISTS `mpx_ask_expert_topic`;
CREATE TABLE `mpx_ask_expert_topic` (
  `aet_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `media_id` int(10) NOT NULL DEFAULT 0,
  `parent` int(10) NOT NULL DEFAULT 0,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_medium` enum('','w','ad') DEFAULT NULL COMMENT 'w=Website,ad=admin',
  `created_by` enum('','a','u') NOT NULL COMMENT 'a=admin,u=user',
  `created_id` bigint(20) NOT NULL,
  `updated_id` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_auth_roles`
--

DROP TABLE IF EXISTS `mpx_auth_roles`;
CREATE TABLE `mpx_auth_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `info` mediumtext DEFAULT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_banner`
--

DROP TABLE IF EXISTS `mpx_banner`;
CREATE TABLE `mpx_banner` (
  `bnr_id` int(10) UNSIGNED NOT NULL,
  `bnr_group` varchar(128) NOT NULL,
  `media_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `title` varchar(128) DEFAULT NULL,
  `descp` mediumtext DEFAULT NULL,
  `link` varchar(128) DEFAULT NULL,
  `link_text` varchar(60) DEFAULT NULL,
  `link_target` varchar(20) DEFAULT NULL,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_benchmark_cache`
--

DROP TABLE IF EXISTS `mpx_benchmark_cache`;
CREATE TABLE `mpx_benchmark_cache` (
  `fund_code` varchar(50) NOT NULL,
  `indices_name` varchar(150) NOT NULL,
  `entry_date` date NOT NULL,
  `fund_name` varchar(200) DEFAULT NULL,
  `sevendays` decimal(15,6) DEFAULT NULL,
  `forteendays` decimal(15,6) DEFAULT NULL,
  `thirtydays` decimal(15,6) DEFAULT NULL,
  `sixtydays` decimal(15,6) DEFAULT NULL,
  `nintydays` decimal(15,6) DEFAULT NULL,
  `sixmonths` decimal(15,6) DEFAULT NULL,
  `oneyear` decimal(15,6) DEFAULT NULL,
  `twoyear` decimal(15,6) DEFAULT NULL,
  `threeyear` decimal(15,6) DEFAULT NULL,
  `fiveyear` decimal(15,6) DEFAULT NULL,
  `oddoneyear` decimal(15,6) DEFAULT NULL,
  `oddtwoyear` decimal(15,6) DEFAULT NULL,
  `to_date` varchar(20) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_benchmark_high_low_cache`
--

DROP TABLE IF EXISTS `mpx_benchmark_high_low_cache`;
CREATE TABLE `mpx_benchmark_high_low_cache` (
  `fund_code` varchar(50) NOT NULL,
  `indices_name` varchar(150) NOT NULL,
  `entry_date` date NOT NULL,
  `high_7` decimal(15,4) DEFAULT NULL,
  `low_7` decimal(15,4) DEFAULT NULL,
  `high_30` decimal(15,4) DEFAULT NULL,
  `low_30` decimal(15,4) DEFAULT NULL,
  `high_90` decimal(15,4) DEFAULT NULL,
  `low_90` decimal(15,4) DEFAULT NULL,
  `high_180` decimal(15,4) DEFAULT NULL,
  `low_180` decimal(15,4) DEFAULT NULL,
  `high_365` decimal(15,4) DEFAULT NULL,
  `low_365` decimal(15,4) DEFAULT NULL,
  `high_730` decimal(15,4) DEFAULT NULL,
  `low_730` decimal(15,4) DEFAULT NULL,
  `high_1095` decimal(15,4) DEFAULT NULL,
  `low_1095` decimal(15,4) DEFAULT NULL,
  `high_1825` decimal(15,4) DEFAULT NULL,
  `low_1825` decimal(15,4) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_blog`
--

DROP TABLE IF EXISTS `mpx_blog`;
CREATE TABLE `mpx_blog` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(255) NOT NULL,
  `sub_category` varchar(100) NOT NULL,
  `heading` varchar(255) NOT NULL,
  `unique_url` varchar(600) NOT NULL,
  `sub_heading` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `image_banner` varchar(255) NOT NULL,
  `image_thumb` varchar(255) NOT NULL,
  `cta_type` int(11) NOT NULL DEFAULT 0,
  `cta_url` varchar(255) DEFAULT NULL,
  `created_by` int(225) NOT NULL COMMENT 'Reference to Admin ID',
  `published_by` int(11) DEFAULT NULL COMMENT 'Reference to Admin ID',
  `published_date` datetime DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 2,
  `tags` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `updated_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_blog_comments`
--

DROP TABLE IF EXISTS `mpx_blog_comments`;
CREATE TABLE `mpx_blog_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 2,
  `updated_id` int(11) DEFAULT NULL,
  `client_ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_cagrs`
--

DROP TABLE IF EXISTS `mpx_cagrs`;
CREATE TABLE `mpx_cagrs` (
  `id` bigint(20) NOT NULL,
  `fund_code` mediumtext DEFAULT NULL,
  `fund_type_id` bigint(20) DEFAULT NULL,
  `cagr_value` double DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `durations` bigint(20) DEFAULT NULL,
  `status` mediumtext DEFAULT NULL,
  `created_at` mediumtext DEFAULT NULL,
  `updated_at` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_calculator_registers`
--

DROP TABLE IF EXISTS `mpx_calculator_registers`;
CREATE TABLE `mpx_calculator_registers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `platform` int(11) NOT NULL DEFAULT 0 COMMENT '0=website, 1=google, 2=facebook',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_cargsnew`
--

DROP TABLE IF EXISTS `mpx_cargsnew`;
CREATE TABLE `mpx_cargsnew` (
  `id` bigint(20) DEFAULT NULL,
  `fund_code` mediumtext DEFAULT NULL,
  `fund_type_id` bigint(20) DEFAULT NULL,
  `cagr_value` mediumtext DEFAULT NULL,
  `start_date` mediumtext DEFAULT NULL,
  `end_date` mediumtext DEFAULT NULL,
  `durations` bigint(20) DEFAULT NULL,
  `status` mediumtext DEFAULT NULL,
  `created_at` mediumtext DEFAULT NULL,
  `updated_at` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_common_category`
--

DROP TABLE IF EXISTS `mpx_common_category`;
CREATE TABLE `mpx_common_category` (
  `cc_id` int(10) UNSIGNED NOT NULL,
  `type` enum('','f') NOT NULL COMMENT 'f=faq',
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `media_id` int(10) NOT NULL DEFAULT 0,
  `parent` int(10) NOT NULL DEFAULT 0,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updated_id` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_corpus`
--

DROP TABLE IF EXISTS `mpx_corpus`;
CREATE TABLE `mpx_corpus` (
  `corpus_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fund` varchar(255) NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_corpus_entry`
--

DROP TABLE IF EXISTS `mpx_corpus_entry`;
CREATE TABLE `mpx_corpus_entry` (
  `ce_id` int(10) UNSIGNED NOT NULL,
  `fund_code` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `corpus_entry` float DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `corpus_change` float DEFAULT NULL,
  `publish` enum('','y','n') NOT NULL DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_corpus_settings`
--

DROP TABLE IF EXISTS `mpx_corpus_settings`;
CREATE TABLE `mpx_corpus_settings` (
  `id` int(11) NOT NULL,
  `year` mediumtext NOT NULL,
  `month` mediumtext NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_currency_cor`
--

DROP TABLE IF EXISTS `mpx_currency_cor`;
CREATE TABLE `mpx_currency_cor` (
  `cc_id` int(10) UNSIGNED NOT NULL,
  `cm_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'currency master id',
  `cor` mediumtext DEFAULT NULL,
  `created_id` int(10) NOT NULL DEFAULT 0,
  `updated_id` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_currency_detail`
--

DROP TABLE IF EXISTS `mpx_currency_detail`;
CREATE TABLE `mpx_currency_detail` (
  `cd_id` bigint(20) UNSIGNED NOT NULL,
  `cm_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'currency master id',
  `entry_date` date NOT NULL,
  `entry_value` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_currency_master`
--

DROP TABLE IF EXISTS `mpx_currency_master`;
CREATE TABLE `mpx_currency_master` (
  `cm_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `is_comodity` int(1) DEFAULT 0,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_custom_field_group`
--

DROP TABLE IF EXISTS `mpx_custom_field_group`;
CREATE TABLE `mpx_custom_field_group` (
  `cf_group_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `c_order` bigint(20) NOT NULL DEFAULT 0,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_custom_field_group_type`
--

DROP TABLE IF EXISTS `mpx_custom_field_group_type`;
CREATE TABLE `mpx_custom_field_group_type` (
  `cf_group_type_id` bigint(20) UNSIGNED NOT NULL,
  `cf_group_id` bigint(20) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_for` enum('','a','w','ap') NOT NULL COMMENT 'a=All(used for both App/Website,w=Website,ap=App',
  `field_options` longtext NOT NULL COMMENT 'user customized Json field options',
  `c_order` bigint(20) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_custom_field_group_type_class_template`
--

DROP TABLE IF EXISTS `mpx_custom_field_group_type_class_template`;
CREATE TABLE `mpx_custom_field_group_type_class_template` (
  `cf_gt_class_template_id` bigint(20) UNSIGNED NOT NULL,
  `cf_group_type_id` bigint(20) NOT NULL,
  `class_id` bigint(20) NOT NULL,
  `template_id` int(10) UNSIGNED NOT NULL,
  `deleted_flag` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Internal use',
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_custom_field_group_type_values`
--

DROP TABLE IF EXISTS `mpx_custom_field_group_type_values`;
CREATE TABLE `mpx_custom_field_group_type_values` (
  `cf_group_type_value_id` bigint(20) UNSIGNED NOT NULL,
  `cf_group_type_id` bigint(20) NOT NULL,
  `cf_gt_class_template_id` bigint(20) NOT NULL,
  `data_id` bigint(20) NOT NULL COMMENT 'Unique Universal identifier for each module class',
  `field_value` longtext NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_custom_field_type`
--

DROP TABLE IF EXISTS `mpx_custom_field_type`;
CREATE TABLE `mpx_custom_field_type` (
  `cf_type_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_default_options` mediumtext NOT NULL COMMENT 'JSON : default generate field options',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_enquiry`
--

DROP TABLE IF EXISTS `mpx_enquiry`;
CREATE TABLE `mpx_enquiry` (
  `enq_id` int(10) UNSIGNED NOT NULL,
  `u_id` bigint(20) NOT NULL DEFAULT 0 COMMENT 'User ID',
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_failed_jobs`
--

DROP TABLE IF EXISTS `mpx_failed_jobs`;
CREATE TABLE `mpx_failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` mediumtext NOT NULL,
  `queue` mediumtext NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_faq`
--

DROP TABLE IF EXISTS `mpx_faq`;
CREATE TABLE `mpx_faq` (
  `faq_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `cc_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Common Category ID',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_category_composition_allocations`
--

DROP TABLE IF EXISTS `mpx_fund_category_composition_allocations`;
CREATE TABLE `mpx_fund_category_composition_allocations` (
  `id` int(11) NOT NULL,
  `fund_name` longtext DEFAULT NULL,
  `cash` double(10,2) DEFAULT NULL,
  `sov` double(10,2) DEFAULT NULL,
  `debt` decimal(10,2) DEFAULT NULL,
  `eq_small` decimal(10,2) DEFAULT NULL,
  `eq_mid` decimal(10,2) DEFAULT NULL,
  `eq_large` decimal(10,2) DEFAULT NULL,
  `eq_very_large` decimal(10,2) DEFAULT NULL,
  `others_val` decimal(10,2) DEFAULT NULL,
  `wt_pe` decimal(10,2) DEFAULT NULL,
  `monthinfo` int(11) DEFAULT NULL,
  `yearinfo` int(11) DEFAULT NULL,
  `fund_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_classifications`
--

DROP TABLE IF EXISTS `mpx_fund_classifications`;
CREATE TABLE `mpx_fund_classifications` (
  `fc_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_composition`
--

DROP TABLE IF EXISTS `mpx_fund_composition`;
CREATE TABLE `mpx_fund_composition` (
  `fc_id` bigint(20) UNSIGNED NOT NULL,
  `entry_date` date NOT NULL,
  `fund_code` varchar(50) NOT NULL,
  `scrip_name` varchar(150) NOT NULL,
  `industry` varchar(128) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `content_per` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `no_of_shares` float DEFAULT NULL,
  `indices_per` float DEFAULT NULL,
  `publish` enum('','y','n') NOT NULL DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `mpx_fund_composition_corpus_entry`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `mpx_fund_composition_corpus_entry`;
CREATE TABLE `mpx_fund_composition_corpus_entry` (
`corpus_entry` float
,`corpus_entry_date` date
,`fund_code` varchar(50)
,`composition_entry_date` date
,`scrip_name` varchar(150)
,`industry` varchar(128)
,`content_per` float
,`calculated_amount` double
,`category` varchar(128)
);

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_core`
--

DROP TABLE IF EXISTS `mpx_fund_core`;
CREATE TABLE `mpx_fund_core` (
  `ftm_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cor` mediumtext DEFAULT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_detail`
--

DROP TABLE IF EXISTS `mpx_fund_detail`;
CREATE TABLE `mpx_fund_detail` (
  `fd_id` bigint(20) UNSIGNED NOT NULL,
  `fund_code` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `closing_nav` float DEFAULT NULL,
  `holiday` tinyint(3) UNSIGNED DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_dictionary`
--

DROP TABLE IF EXISTS `mpx_fund_dictionary`;
CREATE TABLE `mpx_fund_dictionary` (
  `fd_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_man`
--

DROP TABLE IF EXISTS `mpx_fund_man`;
CREATE TABLE `mpx_fund_man` (
  `fm_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `media_id` int(10) NOT NULL DEFAULT 0,
  `designation` varchar(128) DEFAULT NULL,
  `company_name` varchar(128) DEFAULT NULL,
  `synopsis` varchar(512) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `disclaimer` mediumtext DEFAULT NULL,
  `disclaimer_note` varchar(256) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_master`
--

DROP TABLE IF EXISTS `mpx_fund_master`;
CREATE TABLE `mpx_fund_master` (
  `fund_id` int(10) UNSIGNED NOT NULL,
  `fund_name` varchar(255) DEFAULT NULL,
  `fund_code` varchar(50) NOT NULL,
  `fund_manager` varchar(255) DEFAULT NULL,
  `fund_type_id` int(10) NOT NULL DEFAULT 0,
  `fund_term_id` int(10) NOT NULL DEFAULT 0,
  `face_value` double(10,4) NOT NULL DEFAULT 0.0000,
  `risk_free_return` double(10,4) NOT NULL DEFAULT 0.0000,
  `fund_opened` date DEFAULT NULL,
  `period` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `cost` double(10,4) NOT NULL DEFAULT 0.0000,
  `indices_name` varchar(100) DEFAULT NULL,
  `fund_house` varchar(255) DEFAULT NULL,
  `classification` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL,
  `test` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_scrips`
--

DROP TABLE IF EXISTS `mpx_fund_scrips`;
CREATE TABLE `mpx_fund_scrips` (
  `id` int(150) NOT NULL,
  `fw_id` int(10) NOT NULL,
  `fund_code` varchar(255) NOT NULL,
  `scrip_name` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_suggestion`
--

DROP TABLE IF EXISTS `mpx_fund_suggestion`;
CREATE TABLE `mpx_fund_suggestion` (
  `fs_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_taxation`
--

DROP TABLE IF EXISTS `mpx_fund_taxation`;
CREATE TABLE `mpx_fund_taxation` (
  `ft_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_term`
--

DROP TABLE IF EXISTS `mpx_fund_term`;
CREATE TABLE `mpx_fund_term` (
  `ftm_id` int(10) UNSIGNED NOT NULL,
  `term` varchar(255) NOT NULL,
  `days` mediumint(9) NOT NULL DEFAULT 0,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_type`
--

DROP TABLE IF EXISTS `mpx_fund_type`;
CREATE TABLE `mpx_fund_type` (
  `ft_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active_passive` enum('','A','P') DEFAULT NULL COMMENT 'A=Active,P=Passive',
  `monthly_performance` enum('','Y','N') DEFAULT NULL COMMENT 'Y=Yes,N=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch`
--

DROP TABLE IF EXISTS `mpx_fund_watch`;
CREATE TABLE `mpx_fund_watch` (
  `fw_id` int(10) UNSIGNED NOT NULL,
  `fund_code` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `preamble` mediumtext DEFAULT NULL,
  `team` mediumtext DEFAULT NULL,
  `philosophy` mediumtext DEFAULT NULL,
  `investment_style` mediumtext DEFAULT NULL,
  `performance_parameter_bottom` mediumtext DEFAULT NULL,
  `index_rank_bottom` mediumtext DEFAULT NULL,
  `rank_side` mediumtext DEFAULT NULL,
  `risk_adjust_bottom` mediumtext DEFAULT NULL,
  `composition_analysis_top` mediumtext DEFAULT NULL,
  `composition_analysis_bottom` mediumtext DEFAULT NULL,
  `feedback` mediumtext DEFAULT NULL,
  `disclaimer` mediumtext DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL,
  `published_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_disclaimer`
--

DROP TABLE IF EXISTS `mpx_fund_watch_disclaimer`;
CREATE TABLE `mpx_fund_watch_disclaimer` (
  `id` int(11) NOT NULL,
  `disclaimer` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_fund_composition_analyses`
--

DROP TABLE IF EXISTS `mpx_fund_watch_fund_composition_analyses`;
CREATE TABLE `mpx_fund_watch_fund_composition_analyses` (
  `id` int(11) NOT NULL,
  `fund_watch_id` int(11) NOT NULL,
  `fund_code` longtext NOT NULL,
  `scrip_name` longtext NOT NULL,
  `entry_date` date NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `qty1` decimal(10,2) NOT NULL,
  `qty2` decimal(10,2) NOT NULL,
  `qty3` decimal(10,2) NOT NULL,
  `qty4` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_graphs`
--

DROP TABLE IF EXISTS `mpx_fund_watch_graphs`;
CREATE TABLE `mpx_fund_watch_graphs` (
  `id` int(11) NOT NULL,
  `fund_watch_id` int(11) NOT NULL,
  `returnLessIndexRank` longtext NOT NULL,
  `returnLessIndex` longtext NOT NULL,
  `rankQuartile` longtext NOT NULL,
  `rankDecile` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_new`
--

DROP TABLE IF EXISTS `mpx_fund_watch_new`;
CREATE TABLE `mpx_fund_watch_new` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fund_code` varchar(255) NOT NULL COMMENT 'fund master table fund code column',
  `logo` varchar(255) DEFAULT NULL,
  `preamble` blob DEFAULT NULL,
  `team` blob DEFAULT NULL,
  `philosophy` blob DEFAULT NULL,
  `investment_style` blob DEFAULT NULL,
  `performance_parameter_bottom` blob DEFAULT NULL,
  `index_rank_bottom` blob DEFAULT NULL,
  `rank_side` blob DEFAULT NULL,
  `risk_adjust_bottom` blob DEFAULT NULL,
  `composition_analysis_top` blob DEFAULT NULL,
  `composition_analysis_bottom` blob DEFAULT NULL,
  `feedback` blob DEFAULT NULL,
  `disclaimer` blob DEFAULT NULL,
  `status` int(11) NOT NULL,
  `updated_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `published_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_return_continious`
--

DROP TABLE IF EXISTS `mpx_fund_watch_return_continious`;
CREATE TABLE `mpx_fund_watch_return_continious` (
  `id` int(11) NOT NULL,
  `fund_watch_id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `SIXMONTHS` decimal(10,2) NOT NULL,
  `ONEYEAR` decimal(10,2) NOT NULL,
  `TWOYEAR` decimal(10,2) NOT NULL,
  `THREEYEAR` decimal(10,2) NOT NULL,
  `FIVEYEAR` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_return_discontinious`
--

DROP TABLE IF EXISTS `mpx_fund_watch_return_discontinious`;
CREATE TABLE `mpx_fund_watch_return_discontinious` (
  `id` int(11) NOT NULL,
  `fund_watch_id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `SIXMONTHS` decimal(10,2) NOT NULL,
  `ONEYEAR` decimal(10,2) NOT NULL,
  `TWOYEAR` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_fund_watch_risk_ratios`
--

DROP TABLE IF EXISTS `mpx_fund_watch_risk_ratios`;
CREATE TABLE `mpx_fund_watch_risk_ratios` (
  `id` int(11) NOT NULL,
  `fund_watch_id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `jensens_alpha` decimal(10,2) NOT NULL,
  `beta` decimal(10,2) NOT NULL,
  `volatality` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_composition`
--

DROP TABLE IF EXISTS `mpx_indices_composition`;
CREATE TABLE `mpx_indices_composition` (
  `ic_id` bigint(20) UNSIGNED NOT NULL,
  `entry_date` date NOT NULL,
  `indices_name` varchar(150) NOT NULL,
  `correlation_new` varchar(150) DEFAULT NULL,
  `scrip_name` varchar(150) NOT NULL,
  `type` varchar(128) DEFAULT NULL,
  `industry` varchar(128) DEFAULT NULL,
  `percentage` float DEFAULT NULL,
  `publish` enum('','y','n') NOT NULL DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_composition_backup_20260608`
--

DROP TABLE IF EXISTS `mpx_indices_composition_backup_20260608`;
CREATE TABLE `mpx_indices_composition_backup_20260608` (
  `ic_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `entry_date` date NOT NULL,
  `indices_name` varchar(150) NOT NULL,
  `correlation_new` varchar(150) DEFAULT NULL,
  `scrip_name` varchar(150) NOT NULL,
  `type` varchar(128) DEFAULT NULL,
  `industry` varchar(128) DEFAULT NULL,
  `percentage` float DEFAULT NULL,
  `publish` enum('','y','n') NOT NULL DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_corelation`
--

DROP TABLE IF EXISTS `mpx_indices_corelation`;
CREATE TABLE `mpx_indices_corelation` (
  `idc_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `corelation` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_detail`
--

DROP TABLE IF EXISTS `mpx_indices_detail`;
CREATE TABLE `mpx_indices_detail` (
  `idcd_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'It''s a corelation',
  `correlation_new` varchar(255) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `closing_value` float DEFAULT NULL,
  `holiday` tinyint(1) UNSIGNED DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) UNSIGNED DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_detail-15-10-2024`
--

DROP TABLE IF EXISTS `mpx_indices_detail-15-10-2024`;
CREATE TABLE `mpx_indices_detail-15-10-2024` (
  `idcd_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'It''s a corelation',
  `correlation_new` varchar(255) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `closing_value` float DEFAULT NULL,
  `holiday` tinyint(1) UNSIGNED DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) UNSIGNED DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_detail_03032025`
--

DROP TABLE IF EXISTS `mpx_indices_detail_03032025`;
CREATE TABLE `mpx_indices_detail_03032025` (
  `idcd_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'It''s a corelation',
  `correlation_new` varchar(255) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `closing_value` float DEFAULT NULL,
  `holiday` tinyint(1) UNSIGNED DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) UNSIGNED DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_detail_19082025`
--

DROP TABLE IF EXISTS `mpx_indices_detail_19082025`;
CREATE TABLE `mpx_indices_detail_19082025` (
  `idcd_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'It''s a corelation',
  `correlation_new` varchar(255) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `closing_value` float DEFAULT NULL,
  `holiday` tinyint(1) UNSIGNED DEFAULT NULL,
  `percentage_change` float DEFAULT NULL,
  `publish` enum('','y','n') DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED DEFAULT 0,
  `updated_id` int(10) UNSIGNED DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_indices_master`
--

DROP TABLE IF EXISTS `mpx_indices_master`;
CREATE TABLE `mpx_indices_master` (
  `idc_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `corelation` varchar(255) DEFAULT NULL,
  `corelation_old` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_jobs`
--

DROP TABLE IF EXISTS `mpx_jobs`;
CREATE TABLE `mpx_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_know_the_ratio`
--

DROP TABLE IF EXISTS `mpx_know_the_ratio`;
CREATE TABLE `mpx_know_the_ratio` (
  `ktr_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `media_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_lates_from_plexus`
--

DROP TABLE IF EXISTS `mpx_lates_from_plexus`;
CREATE TABLE `mpx_lates_from_plexus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `heading` varchar(255) NOT NULL,
  `sub_heading` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 2 COMMENT '1=enabled:2=disabled',
  `updated_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_mcap_eps`
--

DROP TABLE IF EXISTS `mpx_mcap_eps`;
CREATE TABLE `mpx_mcap_eps` (
  `me_id` bigint(20) UNSIGNED NOT NULL,
  `scrip_name` varchar(150) NOT NULL,
  `entry_date` date NOT NULL,
  `market_cap` float DEFAULT NULL,
  `eps` float DEFAULT NULL,
  `pe` float DEFAULT NULL,
  `publish` enum('','y','n') NOT NULL DEFAULT 'n' COMMENT 'y=Yes,n=No',
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_media`
--

DROP TABLE IF EXISTS `mpx_media`;
CREATE TABLE `mpx_media` (
  `media_id` int(10) UNSIGNED NOT NULL,
  `path` varchar(128) DEFAULT NULL,
  `mime_type` varchar(100) NOT NULL,
  `media_info` mediumtext DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `alt` varchar(128) DEFAULT NULL,
  `descp` mediumtext DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_menu`
--

DROP TABLE IF EXISTS `mpx_menu`;
CREATE TABLE `mpx_menu` (
  `menu_id` int(10) UNSIGNED NOT NULL,
  `menu_type_id` int(10) UNSIGNED NOT NULL,
  `class_id` int(10) NOT NULL DEFAULT 0,
  `data_id` int(10) NOT NULL DEFAULT 0 COMMENT 'universal id',
  `label` varchar(100) DEFAULT NULL,
  `hint` varchar(255) DEFAULT NULL,
  `is_link` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `external_link` varchar(255) DEFAULT NULL,
  `link_target` enum('','_blank','_self') DEFAULT NULL,
  `menu_class` varchar(60) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `parent_menu_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Parent Menu ID',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_menu_type`
--

DROP TABLE IF EXISTS `mpx_menu_type`;
CREATE TABLE `mpx_menu_type` (
  `menu_type_id` int(10) UNSIGNED NOT NULL,
  `label` varchar(128) NOT NULL,
  `menu_name` varchar(128) NOT NULL,
  `menu_for` enum('','p','f','s','o') DEFAULT NULL COMMENT 'p=primary,f=footer,s=sidebar,o=other',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_migrations`
--

DROP TABLE IF EXISTS `mpx_migrations`;
CREATE TABLE `mpx_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_modules`
--

DROP TABLE IF EXISTS `mpx_modules`;
CREATE TABLE `mpx_modules` (
  `module_id` int(10) UNSIGNED NOT NULL,
  `class_id` int(10) UNSIGNED NOT NULL,
  `has_templates` enum('','n','y') NOT NULL COMMENT 'y=Yes,n=No',
  `set_user_rights` enum('','n','y') NOT NULL COMMENT 'y=Yes,n=No',
  `title` varchar(128) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `info` mediumtext DEFAULT NULL,
  `class_name` varchar(191) NOT NULL,
  `is_menu` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `parent_module_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Parent Module ID',
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_module_class`
--

DROP TABLE IF EXISTS `mpx_module_class`;
CREATE TABLE `mpx_module_class` (
  `class_id` int(10) UNSIGNED NOT NULL,
  `class_name` varchar(191) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `info` mediumtext DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_module_class_templates`
--

DROP TABLE IF EXISTS `mpx_module_class_templates`;
CREATE TABLE `mpx_module_class_templates` (
  `module_template_id` int(10) UNSIGNED NOT NULL,
  `class_id` int(10) UNSIGNED NOT NULL,
  `template_id` int(10) UNSIGNED NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_module_methods`
--

DROP TABLE IF EXISTS `mpx_module_methods`;
CREATE TABLE `mpx_module_methods` (
  `method_id` int(10) UNSIGNED NOT NULL,
  `module_id` int(10) UNSIGNED NOT NULL COMMENT 'Module ID',
  `title` varchar(255) NOT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `default_present` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `access_role_id` int(11) NOT NULL DEFAULT 0 COMMENT '0=access to all',
  `route_link` varchar(255) NOT NULL,
  `affected_route_link` varchar(255) DEFAULT NULL,
  `is_left_nav` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `is_external_link` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_module_user_group_rights`
--

DROP TABLE IF EXISTS `mpx_module_user_group_rights`;
CREATE TABLE `mpx_module_user_group_rights` (
  `m_u_g_a_id` int(10) UNSIGNED NOT NULL,
  `module_id` int(10) UNSIGNED NOT NULL,
  `u_g_id` int(10) UNSIGNED NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_module_user_rel`
--

DROP TABLE IF EXISTS `mpx_module_user_rel`;
CREATE TABLE `mpx_module_user_rel` (
  `mur_id` int(10) UNSIGNED NOT NULL,
  `u_id` bigint(20) NOT NULL COMMENT 'User ID',
  `type` enum('','aet') NOT NULL COMMENT 'aet=Ask Expert Topic',
  `data_id` int(10) NOT NULL,
  `updated_id` int(10) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_monthly_fund_house_performance`
--

DROP TABLE IF EXISTS `mpx_monthly_fund_house_performance`;
CREATE TABLE `mpx_monthly_fund_house_performance` (
  `mfhp_id` int(10) UNSIGNED NOT NULL,
  `dated` date NOT NULL,
  `fund_type_id` bigint(20) NOT NULL,
  `timespan` varchar(20) NOT NULL,
  `fund_code` varchar(50) NOT NULL,
  `cagr` decimal(10,2) DEFAULT NULL,
  `cagr_rank` int(11) DEFAULT NULL,
  `cagr_rank_improvement` int(11) DEFAULT NULL,
  `ret_less_idx` decimal(38,2) DEFAULT NULL,
  `ret_less_idx_rank` int(11) DEFAULT NULL,
  `ret_less_idx_rank_improvement` int(11) DEFAULT NULL,
  `jensen` decimal(38,2) DEFAULT NULL,
  `jensen_rank` int(11) DEFAULT NULL,
  `jensen_rank_improvement` int(11) DEFAULT NULL,
  `beta` decimal(38,2) DEFAULT NULL,
  `beta_rank` int(11) DEFAULT NULL,
  `beta_rank_improvement` int(11) DEFAULT NULL,
  `co_var` decimal(38,2) DEFAULT NULL,
  `co_var_rank` int(11) DEFAULT NULL,
  `co_var_rank_improvement` int(11) DEFAULT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_monthly_performance_synopses`
--

DROP TABLE IF EXISTS `mpx_monthly_performance_synopses`;
CREATE TABLE `mpx_monthly_performance_synopses` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `ratio_type` varchar(255) NOT NULL DEFAULT 'returns',
  `fund_id` int(11) NOT NULL,
  `fund_name` varchar(255) NOT NULL,
  `fund_code` varchar(255) NOT NULL,
  `fund_house` varchar(255) NOT NULL,
  `fund_type_id` int(11) NOT NULL,
  `fund_type_status` varchar(255) NOT NULL,
  `fund_type_name` varchar(255) NOT NULL,
  `quartile1` longtext NOT NULL,
  `quartile2` longtext NOT NULL,
  `decile1` longtext NOT NULL,
  `decile2` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_monthly_ratio_calculations`
--

DROP TABLE IF EXISTS `mpx_monthly_ratio_calculations`;
CREATE TABLE `mpx_monthly_ratio_calculations` (
  `id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(100) DEFAULT NULL,
  `fund_name` varchar(255) DEFAULT NULL,
  `per_change_aaum` float DEFAULT NULL,
  `aaum` float DEFAULT NULL,
  `one_year_return` float DEFAULT NULL,
  `p1_volatality` float DEFAULT NULL,
  `p2_volatality` float DEFAULT NULL,
  `p3_volatality` float DEFAULT NULL,
  `p4_volatality` float DEFAULT NULL,
  `p1_beta` float DEFAULT NULL,
  `p2_beta` float DEFAULT NULL,
  `p3_beta` float DEFAULT NULL,
  `p4_beta` float DEFAULT NULL,
  `p1_jensen_alpha` float DEFAULT NULL,
  `p2_jensen_alpha` float DEFAULT NULL,
  `p3_jensen_alpha` float DEFAULT NULL,
  `p4_jensen_alpha` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_news`
--

DROP TABLE IF EXISTS `mpx_news`;
CREATE TABLE `mpx_news` (
  `n_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `media_type` enum('','i','v') DEFAULT NULL COMMENT 'i=image,v=video',
  `image` varchar(255) DEFAULT NULL,
  `video_from` enum('','l','y') DEFAULT NULL COMMENT 'l=local,y=youtube',
  `video_data` varchar(255) DEFAULT NULL,
  `video_image` varchar(255) DEFAULT NULL,
  `news_source` varchar(128) DEFAULT NULL,
  `news_source_link` varchar(500) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_newsletter`
--

DROP TABLE IF EXISTS `mpx_newsletter`;
CREATE TABLE `mpx_newsletter` (
  `n_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_new_from_myplexus`
--

DROP TABLE IF EXISTS `mpx_new_from_myplexus`;
CREATE TABLE `mpx_new_from_myplexus` (
  `id` bigint(10) NOT NULL,
  `type_id` enum('Blog','NFO Monitor','Fund Portfolio','Composition Snapshot','Corpus Details','Monthly Snapshot','Weekly Snapshot','Mutual Fund Taxation','Mutual Fund Classifications','Know The Ratio','Thoughts and Opinion on Funds','Mutual Fund Dictionary','Fund Watch','Compare') NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_new_monthly_ratio_calculations`
--

DROP TABLE IF EXISTS `mpx_new_monthly_ratio_calculations`;
CREATE TABLE `mpx_new_monthly_ratio_calculations` (
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(100) DEFAULT NULL,
  `fund_name` varchar(255) DEFAULT NULL,
  `per_change_aaum` float DEFAULT NULL,
  `aaum` float DEFAULT NULL,
  `one_year_return` float DEFAULT NULL,
  `p1_volatality` float DEFAULT NULL,
  `p2_volatality` float DEFAULT NULL,
  `p3_volatality` float DEFAULT NULL,
  `p4_volatality` float DEFAULT NULL,
  `p1_beta` float DEFAULT NULL,
  `p2_beta` float DEFAULT NULL,
  `p3_beta` float DEFAULT NULL,
  `p4_beta` float DEFAULT NULL,
  `p1_jensen_alpha` float DEFAULT NULL,
  `p2_jensen_alpha` float DEFAULT NULL,
  `p3_jensen_alpha` float DEFAULT NULL,
  `p4_jensen_alpha` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_nfo_offer`
--

DROP TABLE IF EXISTS `mpx_nfo_offer`;
CREATE TABLE `mpx_nfo_offer` (
  `no_id` int(10) UNSIGNED NOT NULL,
  `type` enum('','f','l','t') NOT NULL COMMENT 'f=File,l=Link,t=Text',
  `fund_name` varchar(255) NOT NULL,
  `fund_opening` date NOT NULL,
  `fund_closing` date NOT NULL,
  `ft_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Fund / Scheme Type ID',
  `minimum_investment` varchar(128) DEFAULT NULL,
  `plan` varchar(128) DEFAULT NULL,
  `options` varchar(128) DEFAULT NULL,
  `entry_load` varchar(128) DEFAULT NULL,
  `exit_load` varchar(255) DEFAULT NULL,
  `thereafter` varchar(128) DEFAULT NULL,
  `objective` mediumtext DEFAULT NULL,
  `idc_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Indices / Benchmark ID',
  `fund_manager` varchar(128) DEFAULT NULL,
  `aa_col1_value` varchar(60) DEFAULT NULL,
  `aa_col1_text` varchar(60) DEFAULT NULL,
  `aa_col2_value` varchar(60) DEFAULT NULL,
  `aa_col2_text` varchar(60) DEFAULT NULL,
  `aa_col3_value` varchar(150) DEFAULT NULL,
  `aa_col3_text` varchar(150) DEFAULT NULL,
  `aa_col4_value` varchar(150) DEFAULT NULL,
  `aa_col4_text` varchar(150) DEFAULT NULL,
  `ces_row1_col1_text` varchar(255) DEFAULT NULL,
  `ces_row1_col2_text` varchar(60) DEFAULT NULL,
  `ces_row1_col3_text` varchar(60) DEFAULT NULL,
  `ces_row2_col1_text` varchar(255) DEFAULT NULL,
  `ces_row2_col2_text` varchar(60) DEFAULT NULL,
  `ces_row2_col3_text` varchar(60) DEFAULT NULL,
  `idea_distiller` mediumtext DEFAULT NULL,
  `fund_house_aaum` varchar(128) DEFAULT NULL,
  `fund_manager_experience` varchar(128) DEFAULT NULL,
  `uniqness` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `return` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `risk` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `operability` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `oomph_factor` mediumtext DEFAULT NULL,
  `media_id` int(10) UNSIGNED DEFAULT 0,
  `post_date` date NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_oauth_access_tokens`
--

DROP TABLE IF EXISTS `mpx_oauth_access_tokens`;
CREATE TABLE `mpx_oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` mediumtext DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_oauth_auth_codes`
--

DROP TABLE IF EXISTS `mpx_oauth_auth_codes`;
CREATE TABLE `mpx_oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` mediumtext DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_oauth_clients`
--

DROP TABLE IF EXISTS `mpx_oauth_clients`;
CREATE TABLE `mpx_oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` mediumtext NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `mpx_oauth_personal_access_clients`;
CREATE TABLE `mpx_oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `mpx_oauth_refresh_tokens`;
CREATE TABLE `mpx_oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_options`
--

DROP TABLE IF EXISTS `mpx_options`;
CREATE TABLE `mpx_options` (
  `option_id` int(10) UNSIGNED NOT NULL,
  `field_type` enum('','image','text','textarea','editor','radio','dropdown') NOT NULL,
  `field_label` varchar(64) DEFAULT NULL,
  `option_key` varchar(64) NOT NULL,
  `option_value` mediumtext DEFAULT NULL,
  `options_label` mediumtext DEFAULT NULL COMMENT 'Must be in JSON format.',
  `options_value` mediumtext DEFAULT NULL COMMENT 'Must be in JSON format.',
  `type` enum('','subscription','general','mail_setting','options','custom','social') NOT NULL,
  `field_info` varchar(255) DEFAULT NULL,
  `is_required` enum('','n','y') NOT NULL DEFAULT 'n' COMMENT 'n=no,y=yes',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_pages`
--

DROP TABLE IF EXISTS `mpx_pages`;
CREATE TABLE `mpx_pages` (
  `page_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `media_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `template_id` int(10) UNSIGNED NOT NULL,
  `is_private` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=private access(set access in usergroup),0=public page',
  `note` varchar(256) DEFAULT NULL,
  `meta_title` varchar(128) DEFAULT NULL,
  `meta_key` varchar(128) DEFAULT NULL,
  `meta_descp` mediumtext DEFAULT NULL,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_password_resets`
--

DROP TABLE IF EXISTS `mpx_password_resets`;
CREATE TABLE `mpx_password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_payment_transactions`
--

DROP TABLE IF EXISTS `mpx_payment_transactions`;
CREATE TABLE `mpx_payment_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subscription_id` bigint(20) UNSIGNED DEFAULT NULL,
  `razorpay_order_id` varchar(255) NOT NULL,
  `razorpay_payment_id` varchar(255) DEFAULT NULL,
  `razorpay_signature` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'INR',
  `status` enum('pending','captured','failed','refunded') NOT NULL DEFAULT 'pending',
  `failure_reason` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_personal_access_tokens`
--

DROP TABLE IF EXISTS `mpx_personal_access_tokens`;
CREATE TABLE `mpx_personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` mediumtext DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_plans`
--

DROP TABLE IF EXISTS `mpx_plans`;
CREATE TABLE `mpx_plans` (
  `p_id` int(10) UNSIGNED NOT NULL,
  `plan_name` varchar(128) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `amount` double(6,2) NOT NULL DEFAULT 0.00,
  `plan_type` enum('','ff','lp') NOT NULL DEFAULT 'lp' COMMENT 'ff=Free Forever,lp=Limited Period',
  `duration` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Must be in days',
  `duration_name` varchar(128) DEFAULT NULL,
  `free_trial` enum('','n','y') NOT NULL DEFAULT 'n' COMMENT 'n=no,y=yes',
  `show_on_wa` enum('','n','y') NOT NULL DEFAULT 'n' COMMENT 'n=no,y=yes',
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_risk_free`
--

DROP TABLE IF EXISTS `mpx_risk_free`;
CREATE TABLE `mpx_risk_free` (
  `id` bigint(10) NOT NULL,
  `name` double NOT NULL DEFAULT 0,
  `created_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_risk_tolerance_portfolio_reg`
--

DROP TABLE IF EXISTS `mpx_risk_tolerance_portfolio_reg`;
CREATE TABLE `mpx_risk_tolerance_portfolio_reg` (
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `reg_name` varchar(100) NOT NULL,
  `reg_email` varchar(100) NOT NULL,
  `q1_v1` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v2` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v3` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v4` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v5` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v6` tinyint(4) NOT NULL DEFAULT 0,
  `q1_v7` tinyint(4) NOT NULL DEFAULT 0,
  `q2_v1` tinyint(4) NOT NULL DEFAULT 0,
  `q2_v2` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v1` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v2` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v3` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v4` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v5` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v6` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v7` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v8` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v9` tinyint(4) NOT NULL DEFAULT 0,
  `q3_v10` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_role_module_method_rights`
--

DROP TABLE IF EXISTS `mpx_role_module_method_rights`;
CREATE TABLE `mpx_role_module_method_rights` (
  `role_module_method_right_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL COMMENT 'User Role ID',
  `module_id` int(10) UNSIGNED NOT NULL COMMENT 'Module ID',
  `method_id` int(10) UNSIGNED NOT NULL COMMENT 'Method ID',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_scrips`
--

DROP TABLE IF EXISTS `mpx_scrips`;
CREATE TABLE `mpx_scrips` (
  `scrp_id` int(10) UNSIGNED NOT NULL,
  `scrip_name` varchar(150) NOT NULL,
  `type` varchar(128) DEFAULT NULL,
  `industry` varchar(128) DEFAULT NULL,
  `actual_scrip` varchar(150) NOT NULL,
  `created_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `migration_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_sip_cache`
--

DROP TABLE IF EXISTS `mpx_sip_cache`;
CREATE TABLE `mpx_sip_cache` (
  `fund_code` varchar(50) NOT NULL,
  `last_date` date NOT NULL,
  `onemonth_values` mediumtext DEFAULT NULL,
  `onemonth_dates` mediumtext DEFAULT NULL,
  `onemonth_current` decimal(15,4) DEFAULT NULL,
  `onemonth_invested` decimal(15,4) DEFAULT NULL,
  `threemonths_values` mediumtext DEFAULT NULL,
  `threemonths_dates` mediumtext DEFAULT NULL,
  `threemonths_current` decimal(15,4) DEFAULT NULL,
  `threemonths_invested` decimal(15,4) DEFAULT NULL,
  `sixmonths_values` mediumtext DEFAULT NULL,
  `sixmonths_dates` mediumtext DEFAULT NULL,
  `sixmonths_current` decimal(15,4) DEFAULT NULL,
  `sixmonths_invested` decimal(15,4) DEFAULT NULL,
  `oneyear_values` mediumtext DEFAULT NULL,
  `oneyear_dates` mediumtext DEFAULT NULL,
  `oneyear_current` decimal(15,4) DEFAULT NULL,
  `oneyear_invested` decimal(15,4) DEFAULT NULL,
  `twoyear_values` mediumtext DEFAULT NULL,
  `twoyear_dates` mediumtext DEFAULT NULL,
  `twoyear_current` decimal(15,4) DEFAULT NULL,
  `twoyear_invested` decimal(15,4) DEFAULT NULL,
  `threeyear_values` mediumtext DEFAULT NULL,
  `threeyear_dates` mediumtext DEFAULT NULL,
  `threeyear_current` decimal(15,4) DEFAULT NULL,
  `threeyear_invested` decimal(15,4) DEFAULT NULL,
  `fiveyear_values` mediumtext DEFAULT NULL,
  `fiveyear_dates` mediumtext DEFAULT NULL,
  `fiveyear_current` decimal(15,4) DEFAULT NULL,
  `fiveyear_invested` decimal(15,4) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_subscriptions`
--

DROP TABLE IF EXISTS `mpx_subscriptions`;
CREATE TABLE `mpx_subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `plan_id` bigint(20) UNSIGNED DEFAULT NULL,
  `razorpay_order_id` varchar(255) DEFAULT NULL,
  `razorpay_payment_id` varchar(255) DEFAULT NULL,
  `razorpay_subscription_id` varchar(255) DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly') DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) NOT NULL DEFAULT 'INR',
  `u_id` bigint(20) NOT NULL DEFAULT 0 COMMENT 'User id',
  `u_code` varchar(255) DEFAULT NULL COMMENT 'User code',
  `subscription_type` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `subscription_expiry_date` date DEFAULT NULL,
  `status` enum('','a','e','pending','active','failed','cancelled','expired') NOT NULL DEFAULT '',
  `created_by` enum('','a','u') NOT NULL COMMENT 'a=admin,u=user',
  `created_id` bigint(20) NOT NULL,
  `updated_by` enum('','a','u') DEFAULT NULL COMMENT 'a=admin,u=user',
  `updated_id` bigint(20) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_subscription_plans`
--

DROP TABLE IF EXISTS `mpx_subscription_plans`;
CREATE TABLE `mpx_subscription_plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `price_monthly` decimal(10,2) NOT NULL,
  `price_yearly` decimal(10,2) NOT NULL,
  `duration_months` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `allow_trial` tinyint(1) NOT NULL DEFAULT 1,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `razorpay_plan_id_monthly` varchar(255) DEFAULT NULL,
  `razorpay_plan_id_yearly` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_teams`
--

DROP TABLE IF EXISTS `mpx_teams`;
CREATE TABLE `mpx_teams` (
  `team_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(90) NOT NULL,
  `media_id` int(10) NOT NULL DEFAULT 0,
  `designation` varchar(128) DEFAULT NULL,
  `linkedin_link` varchar(128) DEFAULT NULL,
  `c_order` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updated_id` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_template`
--

DROP TABLE IF EXISTS `mpx_template`;
CREATE TABLE `mpx_template` (
  `template_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_testimonial`
--

DROP TABLE IF EXISTS `mpx_testimonial`;
CREATE TABLE `mpx_testimonial` (
  `tmnl_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(90) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `media_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `designation` varchar(128) DEFAULT NULL,
  `company` varchar(128) DEFAULT NULL,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_users`
--

DROP TABLE IF EXISTS `mpx_users`;
CREATE TABLE `mpx_users` (
  `u_id` bigint(20) UNSIGNED NOT NULL,
  `u_code` varchar(15) DEFAULT NULL COMMENT 'User Code',
  `acc_type` enum('','a','s') DEFAULT NULL COMMENT 'a=Application,s=Social',
  `s_acc_medium` enum('','g','f','m','a') DEFAULT NULL COMMENT 'g=Google,f=Facebook,m=Microsoft,a=Apple',
  `s_account` varchar(30) DEFAULT NULL,
  `f_name` varchar(50) DEFAULT NULL,
  `l_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `forget_code` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `birthday` varchar(10) DEFAULT NULL,
  `p_picture` varchar(255) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `about` varchar(128) DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `company` varchar(128) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `is_approved` enum('','n','y') NOT NULL DEFAULT 'n' COMMENT 'n=no,y=yes',
  `remember_token` varchar(100) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `welcome_email_sent_at` timestamp NULL DEFAULT NULL,
  `note` varchar(128) DEFAULT NULL,
  `created_by` enum('','a','u') DEFAULT NULL COMMENT 'a=admin,u=user',
  `created_id` bigint(20) NOT NULL DEFAULT 0,
  `updated_by` enum('','a','u') DEFAULT NULL COMMENT 'a=admin,u=user',
  `updated_id` bigint(20) NOT NULL DEFAULT 0,
  `user_type` enum('Advisor','Fund House Representative','Investor') DEFAULT NULL,
  `is_contacted_with_team` enum('Yes','No') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `gst` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `arn` varchar(255) DEFAULT NULL,
  `arn_verification_status` varchar(20) NOT NULL DEFAULT 'pending',
  `pan` varchar(255) DEFAULT NULL,
  `subscription_expiry_date` date NOT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `session_token` varchar(100) DEFAULT NULL,
  `is_session_active` tinyint(1) NOT NULL DEFAULT 0,
  `subscription_status` enum('trial','active','expired','cancelled') NOT NULL DEFAULT 'trial',
  `wl_company_name` varchar(255) DEFAULT NULL,
  `wl_logo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_group`
--

DROP TABLE IF EXISTS `mpx_user_group`;
CREATE TABLE `mpx_user_group` (
  `u_g_id` int(10) UNSIGNED NOT NULL,
  `group_name` varchar(60) NOT NULL,
  `descp` mediumtext DEFAULT NULL,
  `c_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_group_pagedata_access`
--

DROP TABLE IF EXISTS `mpx_user_group_pagedata_access`;
CREATE TABLE `mpx_user_group_pagedata_access` (
  `u_g_pd_a_id` bigint(20) UNSIGNED NOT NULL,
  `module_id` int(10) UNSIGNED NOT NULL,
  `u_g_id` int(10) UNSIGNED NOT NULL,
  `data_id` int(10) UNSIGNED NOT NULL COMMENT 'Individual modules page id',
  `created_id` int(10) UNSIGNED NOT NULL,
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_group_rel`
--

DROP TABLE IF EXISTS `mpx_user_group_rel`;
CREATE TABLE `mpx_user_group_rel` (
  `u_g_r_id` int(10) UNSIGNED NOT NULL,
  `u_g_id` int(10) UNSIGNED NOT NULL COMMENT 'User Group ID',
  `u_id` bigint(20) NOT NULL COMMENT 'User ID',
  `updated_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_like`
--

DROP TABLE IF EXISTS `mpx_user_like`;
CREATE TABLE `mpx_user_like` (
  `u_lk_id` int(10) UNSIGNED NOT NULL,
  `type` enum('','ae','aea') NOT NULL COMMENT 'ae=Ask Expert,aea=Ask Expert Answer',
  `data_id` int(10) NOT NULL,
  `u_id` bigint(20) NOT NULL COMMENT 'User ID',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_sensitive_details`
--

DROP TABLE IF EXISTS `mpx_user_sensitive_details`;
CREATE TABLE `mpx_user_sensitive_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pan` varchar(255) DEFAULT NULL,
  `arn` varchar(255) DEFAULT NULL,
  `gst` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mpx_user_subscription`
--

DROP TABLE IF EXISTS `mpx_user_subscription`;
CREATE TABLE `mpx_user_subscription` (
  `us_id` bigint(20) UNSIGNED NOT NULL,
  `u_id` bigint(20) NOT NULL DEFAULT 0 COMMENT 'User id',
  `p_id` int(10) NOT NULL DEFAULT 0 COMMENT 'Plan id',
  `plan_type` enum('','ff','lp') NOT NULL DEFAULT 'lp' COMMENT 'ff=Free Forever,lp=Limited Period',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('','a','e','pending','active','failed','cancelled') NOT NULL DEFAULT 'pending',
  `created_by` enum('','a','u') NOT NULL COMMENT 'a=admin,u=user',
  `created_id` bigint(20) NOT NULL,
  `updated_by` enum('','a','u') DEFAULT NULL COMMENT 'a=admin,u=user',
  `updated_id` bigint(20) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `plan_id` bigint(20) UNSIGNED DEFAULT NULL,
  `razorpay_order_id` varchar(255) DEFAULT NULL,
  `razorpay_payment_id` varchar(255) DEFAULT NULL,
  `razorpay_subscription_id` varchar(255) DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly') DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) NOT NULL DEFAULT 'INR'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `mpx_view_corpus_with_allocation`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `mpx_view_corpus_with_allocation`;
CREATE TABLE `mpx_view_corpus_with_allocation` (
`corpus_entry` float
,`corpus_entry_date` date
,`fund_code` varchar(50)
,`composition_entry_date` date
,`scrip_name` varchar(150)
,`industry` varchar(128)
,`content_per` float
,`calculated_amount` double
,`category` varchar(128)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `mpx_view_fund_nav_monthly_return`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `mpx_view_fund_nav_monthly_return`;
CREATE TABLE `mpx_view_fund_nav_monthly_return` (
`fund_code` varchar(50)
,`month_year` varchar(7)
,`nav_change_percentage` double
);

-- --------------------------------------------------------

--
-- Table structure for table `Newfund_temp`
--

DROP TABLE IF EXISTS `Newfund_temp`;
CREATE TABLE `Newfund_temp` (
  `FUNDTYPE` varchar(100) DEFAULT NULL,
  `MEANVAL` double DEFAULT NULL,
  `MEDIANVAL` double DEFAULT NULL,
  `FundTypeID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_less_fund_monthly`
--

DROP TABLE IF EXISTS `return_less_fund_monthly`;
CREATE TABLE `return_less_fund_monthly` (
  `fund_name` varchar(255) DEFAULT NULL,
  `fund_code` varchar(255) DEFAULT NULL,
  `indices_name` varchar(100) DEFAULT NULL,
  `sixmonths` double DEFAULT NULL,
  `oneyear` double DEFAULT NULL,
  `twoyear` double DEFAULT NULL,
  `threeyear` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_less_fund_weekly`
--

DROP TABLE IF EXISTS `return_less_fund_weekly`;
CREATE TABLE `return_less_fund_weekly` (
  `fund_name` varchar(255) DEFAULT NULL,
  `fund_code` varchar(255) DEFAULT NULL,
  `indices_name` varchar(100) DEFAULT NULL,
  `5DAYS` double DEFAULT NULL,
  `7DAYS` double DEFAULT NULL,
  `14DAYS` double DEFAULT NULL,
  `30DAYS` double DEFAULT NULL,
  `60DAYS` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_less_index_monthly`
--

DROP TABLE IF EXISTS `return_less_index_monthly`;
CREATE TABLE `return_less_index_monthly` (
  `indices_name` varchar(100) DEFAULT NULL,
  `sixmonths` double DEFAULT NULL,
  `oneyear` double DEFAULT NULL,
  `twoyear` double DEFAULT NULL,
  `threeyear` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_less_index_weekly`
--

DROP TABLE IF EXISTS `return_less_index_weekly`;
CREATE TABLE `return_less_index_weekly` (
  `indices_name` varchar(100) DEFAULT NULL,
  `5DAYS` double DEFAULT NULL,
  `7DAYS` double DEFAULT NULL,
  `14DAYS` double DEFAULT NULL,
  `30DAYS` double DEFAULT NULL,
  `60DAYS` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_currencymaster`
--

DROP TABLE IF EXISTS `tb_currencymaster`;
CREATE TABLE `tb_currencymaster` (
  `CurrencyID` int(11) NOT NULL,
  `CurrencyName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_table`
--

DROP TABLE IF EXISTS `test_table`;
CREATE TABLE `test_table` (
  `decileval` double(10,3) NOT NULL,
  `decile1` double(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpComposition`
--

DROP TABLE IF EXISTS `TmpComposition`;
CREATE TABLE `TmpComposition` (
  `fund_code` varchar(50) DEFAULT NULL,
  `SUMCASH` double DEFAULT NULL,
  `SUMSOV` double DEFAULT NULL,
  `SUMDEBT` double DEFAULT NULL,
  `SUMEQSMALL` double DEFAULT NULL,
  `SUMEQMID` double DEFAULT NULL,
  `SUMEQLARGE` double DEFAULT NULL,
  `SUMEQVLARGE` double DEFAULT NULL,
  `SUMOTHERS` double DEFAULT NULL,
  `SUMEPS` double DEFAULT NULL,
  `NOOFSCRIPTS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpIndexTable`
--

DROP TABLE IF EXISTS `TmpIndexTable`;
CREATE TABLE `TmpIndexTable` (
  `index_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `correlation_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `show_order` int(11) DEFAULT NULL,
  `index_type` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpRatioDataPerformance`
--

DROP TABLE IF EXISTS `TmpRatioDataPerformance`;
CREATE TABLE `TmpRatioDataPerformance` (
  `ID` bigint(20) NOT NULL,
  `ENTRYDATE` datetime DEFAULT NULL,
  `FUNDCODE` varchar(25) DEFAULT NULL,
  `INDICES` varchar(100) DEFAULT NULL,
  `INDICESCLOSING` float DEFAULT NULL,
  `INDICESPER` float DEFAULT NULL,
  `FUNDCLOSING` float DEFAULT NULL,
  `FUNDPER` float DEFAULT NULL,
  `INCEPTIONDATE` datetime DEFAULT NULL,
  `RISKFREERETURN` float DEFAULT NULL,
  `FUNDTERM` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpRatioDataPerformanceVolatility`
--

DROP TABLE IF EXISTS `TmpRatioDataPerformanceVolatility`;
CREATE TABLE `TmpRatioDataPerformanceVolatility` (
  `ID` bigint(20) NOT NULL,
  `ENTRYDATE` datetime DEFAULT NULL,
  `FUNDCODE` varchar(25) DEFAULT NULL,
  `INDICES` varchar(100) DEFAULT NULL,
  `INDICESCLOSING` float DEFAULT NULL,
  `INDICESPER` float DEFAULT NULL,
  `FUNDCLOSING` float DEFAULT NULL,
  `FUNDPER` float DEFAULT NULL,
  `INCEPTIONDATE` datetime DEFAULT NULL,
  `RISKFREERETURN` float DEFAULT NULL,
  `FUNDTERM` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpRatioDataPerformanceVolatility_2`
--

DROP TABLE IF EXISTS `TmpRatioDataPerformanceVolatility_2`;
CREATE TABLE `TmpRatioDataPerformanceVolatility_2` (
  `ID` bigint(20) NOT NULL,
  `ENTRYDATE` datetime DEFAULT NULL,
  `FUNDCODE` varchar(25) DEFAULT NULL,
  `INDICES` varchar(100) DEFAULT NULL,
  `INDICESCLOSING` float DEFAULT NULL,
  `INDICESPER` float DEFAULT NULL,
  `FUNDCLOSING` float DEFAULT NULL,
  `FUNDPER` float DEFAULT NULL,
  `INCEPTIONDATE` datetime DEFAULT NULL,
  `RISKFREERETURN` float DEFAULT NULL,
  `FUNDTERM` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TmpRatioDataSchemeAlpha`
--

DROP TABLE IF EXISTS `TmpRatioDataSchemeAlpha`;
CREATE TABLE `TmpRatioDataSchemeAlpha` (
  `ID` bigint(20) NOT NULL,
  `ENTRYDATE` datetime DEFAULT NULL,
  `FUNDCODE` varchar(50) DEFAULT NULL,
  `INDICES` varchar(100) DEFAULT NULL,
  `INDICESCLOSING` float DEFAULT NULL,
  `INDICESPER` float DEFAULT NULL,
  `FUNDCLOSING` float DEFAULT NULL,
  `FUNDPER` float DEFAULT NULL,
  `INCEPTIONDATE` datetime DEFAULT NULL,
  `RISKFREERETURN` float DEFAULT NULL,
  `FUNDTERM` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TMP_FUND_PE`
--

DROP TABLE IF EXISTS `TMP_FUND_PE`;
CREATE TABLE `TMP_FUND_PE` (
  `fund_code` varchar(100) DEFAULT NULL,
  `weighted_pe` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TMP_FUND_PORTFOLIO`
--

DROP TABLE IF EXISTS `TMP_FUND_PORTFOLIO`;
CREATE TABLE `TMP_FUND_PORTFOLIO` (
  `fund_code` varchar(100) DEFAULT NULL,
  `scrip_name` varchar(255) DEFAULT NULL,
  `market_cap` double DEFAULT NULL,
  `content_per` double DEFAULT NULL,
  `pe` double DEFAULT NULL,
  `weighted_pe` double DEFAULT NULL,
  `status` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_ratio_data_perfornmance`
--

DROP TABLE IF EXISTS `tmp_ratio_data_perfornmance`;
CREATE TABLE `tmp_ratio_data_perfornmance` (
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(25) DEFAULT NULL,
  `per_return` float DEFAULT NULL,
  `volatality` float DEFAULT NULL,
  `volatality2` float DEFAULT NULL,
  `beta` float DEFAULT NULL,
  `beta2` float DEFAULT NULL,
  `jensen_alpha` float DEFAULT NULL,
  `jensen_alpha2` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_ratio_data_perfornmance_volatility`
--

DROP TABLE IF EXISTS `tmp_ratio_data_perfornmance_volatility`;
CREATE TABLE `tmp_ratio_data_perfornmance_volatility` (
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(25) DEFAULT NULL,
  `per_return` float DEFAULT NULL,
  `volatality` float DEFAULT NULL,
  `beta` float DEFAULT NULL,
  `jensen_alpha` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_ratio_data_perfornmance_volatility_2`
--

DROP TABLE IF EXISTS `tmp_ratio_data_perfornmance_volatility_2`;
CREATE TABLE `tmp_ratio_data_perfornmance_volatility_2` (
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(25) DEFAULT NULL,
  `per_return` float DEFAULT NULL,
  `volatality` float DEFAULT NULL,
  `beta` float DEFAULT NULL,
  `jensen_alpha` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_ratio_data_schemealpha`
--

DROP TABLE IF EXISTS `tmp_ratio_data_schemealpha`;
CREATE TABLE `tmp_ratio_data_schemealpha` (
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `fund_code` varchar(50) DEFAULT NULL,
  `jensen_alpha_7dy` float DEFAULT NULL,
  `jensen_alpha_30dy` float DEFAULT NULL,
  `jensen_alpha_90dy` float DEFAULT NULL,
  `jensen_alpha_6mo` float DEFAULT NULL,
  `jensen_alpha_1yr` float DEFAULT NULL,
  `jensen_alpha_2yr` float DEFAULT NULL,
  `jensen_alpha_3yr` float DEFAULT NULL,
  `jensen_alpha_5yr` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `back_up_mpx_fund_dictionary`
--
ALTER TABLE `back_up_mpx_fund_dictionary`
  ADD PRIMARY KEY (`fd_id`);

--
-- Indexes for table `back_up_mpx_fund_type`
--
ALTER TABLE `back_up_mpx_fund_type`
  ADD PRIMARY KEY (`ft_id`);

--
-- Indexes for table `back_up_mpx_fund_watch`
--
ALTER TABLE `back_up_mpx_fund_watch`
  ADD PRIMARY KEY (`fw_id`);

--
-- Indexes for table `back_up_mpx_monthly_fund_house_performance`
--
ALTER TABLE `back_up_mpx_monthly_fund_house_performance`
  ADD PRIMARY KEY (`mfhp_id`),
  ADD UNIQUE KEY `dtd_fti_tmspn_fc` (`dated`,`fund_type_id`,`timespan`,`fund_code`);

--
-- Indexes for table `back_up_mpx_nfo_offer`
--
ALTER TABLE `back_up_mpx_nfo_offer`
  ADD PRIMARY KEY (`no_id`);

--
-- Indexes for table `fund_watch_disclaimer`
--
ALTER TABLE `fund_watch_disclaimer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_admin`
--
ALTER TABLE `mpx_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `mpx_admin_username_unique` (`username`),
  ADD UNIQUE KEY `mpx_admin_email_unique` (`email`);

--
-- Indexes for table `mpx_ask_expert_question`
--
ALTER TABLE `mpx_ask_expert_question`
  ADD PRIMARY KEY (`aeq_id`);

--
-- Indexes for table `mpx_ask_expert_question_answer`
--
ALTER TABLE `mpx_ask_expert_question_answer`
  ADD PRIMARY KEY (`aeqa_id`);

--
-- Indexes for table `mpx_ask_expert_topic`
--
ALTER TABLE `mpx_ask_expert_topic`
  ADD PRIMARY KEY (`aet_id`);

--
-- Indexes for table `mpx_auth_roles`
--
ALTER TABLE `mpx_auth_roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `mpx_auth_roles_title_unique` (`title`);

--
-- Indexes for table `mpx_banner`
--
ALTER TABLE `mpx_banner`
  ADD PRIMARY KEY (`bnr_id`);

--
-- Indexes for table `mpx_benchmark_cache`
--
ALTER TABLE `mpx_benchmark_cache`
  ADD PRIMARY KEY (`fund_code`),
  ADD KEY `idx_entry_date` (`entry_date`);

--
-- Indexes for table `mpx_benchmark_high_low_cache`
--
ALTER TABLE `mpx_benchmark_high_low_cache`
  ADD PRIMARY KEY (`fund_code`),
  ADD KEY `idx_indices_name` (`indices_name`);

--
-- Indexes for table `mpx_blog`
--
ALTER TABLE `mpx_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_blog_comments`
--
ALTER TABLE `mpx_blog_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpx_blog_comments_blog_id_foreign` (`blog_id`);

--
-- Indexes for table `mpx_cagrs`
--
ALTER TABLE `mpx_cagrs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fund_code` (`fund_code`(768)),
  ADD KEY `fund_type_id` (`fund_type_id`);

--
-- Indexes for table `mpx_calculator_registers`
--
ALTER TABLE `mpx_calculator_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_cargsnew`
--
ALTER TABLE `mpx_cargsnew`
  ADD KEY `ix_mpx_cargsnew_id` (`id`);

--
-- Indexes for table `mpx_common_category`
--
ALTER TABLE `mpx_common_category`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indexes for table `mpx_corpus`
--
ALTER TABLE `mpx_corpus`
  ADD PRIMARY KEY (`corpus_id`),
  ADD UNIQUE KEY `fund_id_fund_unique` (`fund_id`,`fund`);

--
-- Indexes for table `mpx_corpus_entry`
--
ALTER TABLE `mpx_corpus_entry`
  ADD PRIMARY KEY (`ce_id`),
  ADD UNIQUE KEY `fund_code_entry_date` (`fund_code`,`entry_date`);

--
-- Indexes for table `mpx_corpus_settings`
--
ALTER TABLE `mpx_corpus_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `status` (`status`);

--
-- Indexes for table `mpx_currency_cor`
--
ALTER TABLE `mpx_currency_cor`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indexes for table `mpx_currency_detail`
--
ALTER TABLE `mpx_currency_detail`
  ADD PRIMARY KEY (`cd_id`),
  ADD UNIQUE KEY `cm_id_entry_date` (`cm_id`,`entry_date`);

--
-- Indexes for table `mpx_currency_master`
--
ALTER TABLE `mpx_currency_master`
  ADD PRIMARY KEY (`cm_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `mpx_custom_field_group`
--
ALTER TABLE `mpx_custom_field_group`
  ADD PRIMARY KEY (`cf_group_id`);

--
-- Indexes for table `mpx_custom_field_group_type`
--
ALTER TABLE `mpx_custom_field_group_type`
  ADD PRIMARY KEY (`cf_group_type_id`);

--
-- Indexes for table `mpx_custom_field_group_type_class_template`
--
ALTER TABLE `mpx_custom_field_group_type_class_template`
  ADD PRIMARY KEY (`cf_gt_class_template_id`),
  ADD UNIQUE KEY `cf_gtype_class_template` (`cf_group_type_id`,`class_id`,`template_id`) USING BTREE;

--
-- Indexes for table `mpx_custom_field_group_type_values`
--
ALTER TABLE `mpx_custom_field_group_type_values`
  ADD PRIMARY KEY (`cf_group_type_value_id`);

--
-- Indexes for table `mpx_custom_field_type`
--
ALTER TABLE `mpx_custom_field_type`
  ADD PRIMARY KEY (`cf_type_id`);

--
-- Indexes for table `mpx_enquiry`
--
ALTER TABLE `mpx_enquiry`
  ADD PRIMARY KEY (`enq_id`);

--
-- Indexes for table `mpx_failed_jobs`
--
ALTER TABLE `mpx_failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mpx_failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `mpx_faq`
--
ALTER TABLE `mpx_faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `mpx_fund_category_composition_allocations`
--
ALTER TABLE `mpx_fund_category_composition_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `mpx_fund_classifications`
--
ALTER TABLE `mpx_fund_classifications`
  ADD PRIMARY KEY (`fc_id`),
  ADD KEY `title` (`title`);

--
-- Indexes for table `mpx_fund_composition`
--
ALTER TABLE `mpx_fund_composition`
  ADD PRIMARY KEY (`fc_id`),
  ADD KEY `ed_fc_sn` (`entry_date`,`fund_code`,`scrip_name`) USING BTREE,
  ADD KEY `entry_date` (`entry_date`,`fund_code`,`scrip_name`),
  ADD KEY `industry` (`industry`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `mpx_fund_core`
--
ALTER TABLE `mpx_fund_core`
  ADD PRIMARY KEY (`ftm_id`),
  ADD UNIQUE KEY `mpx_fund_core_fund_id_unique` (`fund_id`);
ALTER TABLE `mpx_fund_core` ADD FULLTEXT KEY `cor` (`cor`);

--
-- Indexes for table `mpx_fund_detail`
--
ALTER TABLE `mpx_fund_detail`
  ADD PRIMARY KEY (`fd_id`),
  ADD UNIQUE KEY `fund_code_entry_date` (`fund_code`,`entry_date`),
  ADD KEY `entry_date` (`entry_date`,`fund_code`),
  ADD KEY `publish` (`publish`),
  ADD KEY `closing_nav` (`closing_nav`),
  ADD KEY `percentage_change` (`percentage_change`),
  ADD KEY `holiday` (`holiday`);

--
-- Indexes for table `mpx_fund_dictionary`
--
ALTER TABLE `mpx_fund_dictionary`
  ADD PRIMARY KEY (`fd_id`);

--
-- Indexes for table `mpx_fund_man`
--
ALTER TABLE `mpx_fund_man`
  ADD PRIMARY KEY (`fm_id`);

--
-- Indexes for table `mpx_fund_master`
--
ALTER TABLE `mpx_fund_master`
  ADD PRIMARY KEY (`fund_id`),
  ADD UNIQUE KEY `mpx_fund_master_fund_code_unique` (`fund_code`),
  ADD KEY `fund_code` (`fund_code`,`status`),
  ADD KEY `fund_name` (`fund_name`),
  ADD KEY `fund_type_id` (`fund_type_id`),
  ADD KEY `fund_type_id_2` (`fund_type_id`),
  ADD KEY `indices_name` (`indices_name`),
  ADD KEY `fund_opened` (`fund_opened`),
  ADD KEY `fund_house` (`fund_house`),
  ADD KEY `classification` (`classification`);

--
-- Indexes for table `mpx_fund_scrips`
--
ALTER TABLE `mpx_fund_scrips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_suggestion`
--
ALTER TABLE `mpx_fund_suggestion`
  ADD PRIMARY KEY (`fs_id`);

--
-- Indexes for table `mpx_fund_taxation`
--
ALTER TABLE `mpx_fund_taxation`
  ADD PRIMARY KEY (`ft_id`);

--
-- Indexes for table `mpx_fund_term`
--
ALTER TABLE `mpx_fund_term`
  ADD PRIMARY KEY (`ftm_id`),
  ADD KEY `term` (`term`);

--
-- Indexes for table `mpx_fund_type`
--
ALTER TABLE `mpx_fund_type`
  ADD PRIMARY KEY (`ft_id`),
  ADD KEY `name` (`name`),
  ADD KEY `active_passive` (`active_passive`);

--
-- Indexes for table `mpx_fund_watch`
--
ALTER TABLE `mpx_fund_watch`
  ADD PRIMARY KEY (`fw_id`);

--
-- Indexes for table `mpx_fund_watch_disclaimer`
--
ALTER TABLE `mpx_fund_watch_disclaimer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_fund_composition_analyses`
--
ALTER TABLE `mpx_fund_watch_fund_composition_analyses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_graphs`
--
ALTER TABLE `mpx_fund_watch_graphs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_new`
--
ALTER TABLE `mpx_fund_watch_new`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_return_continious`
--
ALTER TABLE `mpx_fund_watch_return_continious`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_return_discontinious`
--
ALTER TABLE `mpx_fund_watch_return_discontinious`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_fund_watch_risk_ratios`
--
ALTER TABLE `mpx_fund_watch_risk_ratios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_indices_composition`
--
ALTER TABLE `mpx_indices_composition`
  ADD PRIMARY KEY (`ic_id`),
  ADD UNIQUE KEY `ed_in_sn` (`entry_date`,`indices_name`,`scrip_name`),
  ADD KEY `entry_date` (`entry_date`,`indices_name`,`scrip_name`),
  ADD KEY `type` (`type`),
  ADD KEY `industry` (`industry`);

--
-- Indexes for table `mpx_indices_corelation`
--
ALTER TABLE `mpx_indices_corelation`
  ADD PRIMARY KEY (`idc_id`),
  ADD KEY `name` (`name`),
  ADD KEY `corelation` (`corelation`);

--
-- Indexes for table `mpx_indices_detail`
--
ALTER TABLE `mpx_indices_detail`
  ADD PRIMARY KEY (`idcd_id`),
  ADD UNIQUE KEY `indices_name_entry_date` (`name`,`entry_date`),
  ADD KEY `closing_value` (`closing_value`),
  ADD KEY `closing_value_2` (`closing_value`),
  ADD KEY `percentage_change` (`percentage_change`),
  ADD KEY `publish` (`publish`);

--
-- Indexes for table `mpx_indices_detail-15-10-2024`
--
ALTER TABLE `mpx_indices_detail-15-10-2024`
  ADD PRIMARY KEY (`idcd_id`),
  ADD UNIQUE KEY `indices_name_entry_date` (`name`,`entry_date`),
  ADD KEY `closing_value` (`closing_value`),
  ADD KEY `closing_value_2` (`closing_value`),
  ADD KEY `percentage_change` (`percentage_change`),
  ADD KEY `publish` (`publish`);

--
-- Indexes for table `mpx_indices_detail_03032025`
--
ALTER TABLE `mpx_indices_detail_03032025`
  ADD PRIMARY KEY (`idcd_id`),
  ADD UNIQUE KEY `indices_name_entry_date` (`name`,`entry_date`),
  ADD KEY `closing_value` (`closing_value`),
  ADD KEY `closing_value_2` (`closing_value`),
  ADD KEY `percentage_change` (`percentage_change`),
  ADD KEY `publish` (`publish`);

--
-- Indexes for table `mpx_indices_detail_19082025`
--
ALTER TABLE `mpx_indices_detail_19082025`
  ADD PRIMARY KEY (`idcd_id`),
  ADD UNIQUE KEY `indices_name_entry_date` (`name`,`entry_date`),
  ADD KEY `closing_value` (`closing_value`),
  ADD KEY `closing_value_2` (`closing_value`),
  ADD KEY `percentage_change` (`percentage_change`),
  ADD KEY `publish` (`publish`);

--
-- Indexes for table `mpx_indices_master`
--
ALTER TABLE `mpx_indices_master`
  ADD PRIMARY KEY (`idc_id`),
  ADD KEY `name` (`name`),
  ADD KEY `corelation` (`corelation`),
  ADD KEY `corelation_old` (`corelation_old`);

--
-- Indexes for table `mpx_jobs`
--
ALTER TABLE `mpx_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `7gn_jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Indexes for table `mpx_know_the_ratio`
--
ALTER TABLE `mpx_know_the_ratio`
  ADD PRIMARY KEY (`ktr_id`);

--
-- Indexes for table `mpx_lates_from_plexus`
--
ALTER TABLE `mpx_lates_from_plexus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_mcap_eps`
--
ALTER TABLE `mpx_mcap_eps`
  ADD PRIMARY KEY (`me_id`),
  ADD UNIQUE KEY `scrip_name_entry_date` (`scrip_name`,`entry_date`);

--
-- Indexes for table `mpx_media`
--
ALTER TABLE `mpx_media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `mpx_menu`
--
ALTER TABLE `mpx_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `mpx_menu_type`
--
ALTER TABLE `mpx_menu_type`
  ADD PRIMARY KEY (`menu_type_id`),
  ADD UNIQUE KEY `mpx_menu_type_menu_name_unique` (`menu_name`);

--
-- Indexes for table `mpx_migrations`
--
ALTER TABLE `mpx_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_modules`
--
ALTER TABLE `mpx_modules`
  ADD PRIMARY KEY (`module_id`),
  ADD UNIQUE KEY `mpx_modules_class_name_unique` (`class_name`);

--
-- Indexes for table `mpx_module_class`
--
ALTER TABLE `mpx_module_class`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `mpx_module_class_class_name_unique` (`class_name`),
  ADD UNIQUE KEY `mpx_module_class_slug_unique` (`slug`);

--
-- Indexes for table `mpx_module_class_templates`
--
ALTER TABLE `mpx_module_class_templates`
  ADD PRIMARY KEY (`module_template_id`),
  ADD UNIQUE KEY `cls_tmp_unq` (`class_id`,`template_id`);

--
-- Indexes for table `mpx_module_methods`
--
ALTER TABLE `mpx_module_methods`
  ADD PRIMARY KEY (`method_id`);

--
-- Indexes for table `mpx_module_user_group_rights`
--
ALTER TABLE `mpx_module_user_group_rights`
  ADD PRIMARY KEY (`m_u_g_a_id`),
  ADD UNIQUE KEY `mpx_module_user_group_rights_module_id_unique` (`module_id`),
  ADD UNIQUE KEY `mpx_module_user_group_rights_u_g_id_unique` (`u_g_id`);

--
-- Indexes for table `mpx_module_user_rel`
--
ALTER TABLE `mpx_module_user_rel`
  ADD PRIMARY KEY (`mur_id`);

--
-- Indexes for table `mpx_monthly_fund_house_performance`
--
ALTER TABLE `mpx_monthly_fund_house_performance`
  ADD PRIMARY KEY (`mfhp_id`),
  ADD UNIQUE KEY `dtd_fti_tmspn_fc` (`dated`,`fund_type_id`,`timespan`,`fund_code`);

--
-- Indexes for table `mpx_monthly_performance_synopses`
--
ALTER TABLE `mpx_monthly_performance_synopses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_monthly_ratio_calculations`
--
ALTER TABLE `mpx_monthly_ratio_calculations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `start_date` (`start_date`),
  ADD KEY `fund_code` (`fund_code`),
  ADD KEY `fund_name` (`fund_name`),
  ADD KEY `aaum` (`aaum`),
  ADD KEY `one_year_return` (`one_year_return`);

--
-- Indexes for table `mpx_news`
--
ALTER TABLE `mpx_news`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `mpx_newsletter`
--
ALTER TABLE `mpx_newsletter`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `mpx_new_from_myplexus`
--
ALTER TABLE `mpx_new_from_myplexus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_nfo_offer`
--
ALTER TABLE `mpx_nfo_offer`
  ADD PRIMARY KEY (`no_id`);

--
-- Indexes for table `mpx_oauth_access_tokens`
--
ALTER TABLE `mpx_oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpx_oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `mpx_oauth_auth_codes`
--
ALTER TABLE `mpx_oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpx_oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `mpx_oauth_clients`
--
ALTER TABLE `mpx_oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpx_oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `mpx_oauth_personal_access_clients`
--
ALTER TABLE `mpx_oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_oauth_refresh_tokens`
--
ALTER TABLE `mpx_oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mpx_oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `mpx_options`
--
ALTER TABLE `mpx_options`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `mpx_pages`
--
ALTER TABLE `mpx_pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `mpx_password_resets`
--
ALTER TABLE `mpx_password_resets`
  ADD KEY `mpx_password_resets_email_index` (`email`);

--
-- Indexes for table `mpx_payment_transactions`
--
ALTER TABLE `mpx_payment_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_personal_access_tokens`
--
ALTER TABLE `mpx_personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mpx_personal_access_tokens_token_unique` (`token`),
  ADD KEY `mpx_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `mpx_plans`
--
ALTER TABLE `mpx_plans`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `mpx_risk_free`
--
ALTER TABLE `mpx_risk_free`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_risk_tolerance_portfolio_reg`
--
ALTER TABLE `mpx_risk_tolerance_portfolio_reg`
  ADD PRIMARY KEY (`portfolio_id`);

--
-- Indexes for table `mpx_role_module_method_rights`
--
ALTER TABLE `mpx_role_module_method_rights`
  ADD PRIMARY KEY (`role_module_method_right_id`),
  ADD UNIQUE KEY `mpx_role_module_method_rights_role_id_module_id_method_id_unique` (`role_id`,`module_id`,`method_id`);

--
-- Indexes for table `mpx_scrips`
--
ALTER TABLE `mpx_scrips`
  ADD PRIMARY KEY (`scrp_id`),
  ADD UNIQUE KEY `name_actual_scrip` (`scrip_name`,`actual_scrip`),
  ADD KEY `scrip_name` (`scrip_name`),
  ADD KEY `scrip_name_2` (`scrip_name`,`type`,`industry`,`actual_scrip`);

--
-- Indexes for table `mpx_sip_cache`
--
ALTER TABLE `mpx_sip_cache`
  ADD PRIMARY KEY (`fund_code`),
  ADD KEY `idx_last_date` (`last_date`);

--
-- Indexes for table `mpx_subscriptions`
--
ALTER TABLE `mpx_subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mpx_subscription_plans`
--
ALTER TABLE `mpx_subscription_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mpx_subscription_plans_slug_unique` (`slug`);

--
-- Indexes for table `mpx_teams`
--
ALTER TABLE `mpx_teams`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `mpx_template`
--
ALTER TABLE `mpx_template`
  ADD PRIMARY KEY (`template_id`);

--
-- Indexes for table `mpx_testimonial`
--
ALTER TABLE `mpx_testimonial`
  ADD PRIMARY KEY (`tmnl_id`);

--
-- Indexes for table `mpx_users`
--
ALTER TABLE `mpx_users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `mpx_users_email_unique` (`email`),
  ADD UNIQUE KEY `mpx_users_u_code_unique` (`u_code`);

--
-- Indexes for table `mpx_user_group`
--
ALTER TABLE `mpx_user_group`
  ADD PRIMARY KEY (`u_g_id`);

--
-- Indexes for table `mpx_user_group_pagedata_access`
--
ALTER TABLE `mpx_user_group_pagedata_access`
  ADD PRIMARY KEY (`u_g_pd_a_id`),
  ADD UNIQUE KEY `module_id` (`module_id`,`u_g_id`,`data_id`);

--
-- Indexes for table `mpx_user_group_rel`
--
ALTER TABLE `mpx_user_group_rel`
  ADD PRIMARY KEY (`u_g_r_id`);

--
-- Indexes for table `mpx_user_like`
--
ALTER TABLE `mpx_user_like`
  ADD PRIMARY KEY (`u_lk_id`);

--
-- Indexes for table `mpx_user_sensitive_details`
--
ALTER TABLE `mpx_user_sensitive_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mpx_user_sensitive_details_user_id_unique` (`user_id`);

--
-- Indexes for table `mpx_user_subscription`
--
ALTER TABLE `mpx_user_subscription`
  ADD PRIMARY KEY (`us_id`);

--
-- Indexes for table `return_less_fund_monthly`
--
ALTER TABLE `return_less_fund_monthly`
  ADD KEY `idx_return_less_fund` (`fund_code`);

--
-- Indexes for table `return_less_fund_weekly`
--
ALTER TABLE `return_less_fund_weekly`
  ADD KEY `idx_scrip_name` (`fund_code`);

--
-- Indexes for table `return_less_index_monthly`
--
ALTER TABLE `return_less_index_monthly`
  ADD KEY `idx_return_less_index` (`indices_name`);

--
-- Indexes for table `return_less_index_weekly`
--
ALTER TABLE `return_less_index_weekly`
  ADD KEY `idx_rank` (`indices_name`);

--
-- Indexes for table `tb_currencymaster`
--
ALTER TABLE `tb_currencymaster`
  ADD PRIMARY KEY (`CurrencyID`);

--
-- Indexes for table `TmpComposition`
--
ALTER TABLE `TmpComposition`
  ADD KEY `idx_composition_code` (`fund_code`);

--
-- Indexes for table `TmpRatioDataPerformance`
--
ALTER TABLE `TmpRatioDataPerformance`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TmpRatioDataPerformanceVolatility`
--
ALTER TABLE `TmpRatioDataPerformanceVolatility`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TmpRatioDataPerformanceVolatility_2`
--
ALTER TABLE `TmpRatioDataPerformanceVolatility_2`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TmpRatioDataSchemeAlpha`
--
ALTER TABLE `TmpRatioDataSchemeAlpha`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TMP_FUND_PE`
--
ALTER TABLE `TMP_FUND_PE`
  ADD KEY `idx_fund_code` (`fund_code`);

--
-- Indexes for table `TMP_FUND_PORTFOLIO`
--
ALTER TABLE `TMP_FUND_PORTFOLIO`
  ADD KEY `idx_pf_scrip` (`scrip_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `back_up_mpx_fund_dictionary`
--
ALTER TABLE `back_up_mpx_fund_dictionary`
  MODIFY `fd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `back_up_mpx_fund_type`
--
ALTER TABLE `back_up_mpx_fund_type`
  MODIFY `ft_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `back_up_mpx_fund_watch`
--
ALTER TABLE `back_up_mpx_fund_watch`
  MODIFY `fw_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `back_up_mpx_monthly_fund_house_performance`
--
ALTER TABLE `back_up_mpx_monthly_fund_house_performance`
  MODIFY `mfhp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `back_up_mpx_nfo_offer`
--
ALTER TABLE `back_up_mpx_nfo_offer`
  MODIFY `no_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fund_watch_disclaimer`
--
ALTER TABLE `fund_watch_disclaimer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_admin`
--
ALTER TABLE `mpx_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_ask_expert_question`
--
ALTER TABLE `mpx_ask_expert_question`
  MODIFY `aeq_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_ask_expert_question_answer`
--
ALTER TABLE `mpx_ask_expert_question_answer`
  MODIFY `aeqa_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_ask_expert_topic`
--
ALTER TABLE `mpx_ask_expert_topic`
  MODIFY `aet_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_auth_roles`
--
ALTER TABLE `mpx_auth_roles`
  MODIFY `role_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_banner`
--
ALTER TABLE `mpx_banner`
  MODIFY `bnr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_blog`
--
ALTER TABLE `mpx_blog`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_blog_comments`
--
ALTER TABLE `mpx_blog_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_cagrs`
--
ALTER TABLE `mpx_cagrs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_calculator_registers`
--
ALTER TABLE `mpx_calculator_registers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_common_category`
--
ALTER TABLE `mpx_common_category`
  MODIFY `cc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_corpus`
--
ALTER TABLE `mpx_corpus`
  MODIFY `corpus_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_corpus_entry`
--
ALTER TABLE `mpx_corpus_entry`
  MODIFY `ce_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_corpus_settings`
--
ALTER TABLE `mpx_corpus_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_currency_cor`
--
ALTER TABLE `mpx_currency_cor`
  MODIFY `cc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_currency_detail`
--
ALTER TABLE `mpx_currency_detail`
  MODIFY `cd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_currency_master`
--
ALTER TABLE `mpx_currency_master`
  MODIFY `cm_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_custom_field_group`
--
ALTER TABLE `mpx_custom_field_group`
  MODIFY `cf_group_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_custom_field_group_type`
--
ALTER TABLE `mpx_custom_field_group_type`
  MODIFY `cf_group_type_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_custom_field_group_type_class_template`
--
ALTER TABLE `mpx_custom_field_group_type_class_template`
  MODIFY `cf_gt_class_template_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_custom_field_group_type_values`
--
ALTER TABLE `mpx_custom_field_group_type_values`
  MODIFY `cf_group_type_value_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_custom_field_type`
--
ALTER TABLE `mpx_custom_field_type`
  MODIFY `cf_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_enquiry`
--
ALTER TABLE `mpx_enquiry`
  MODIFY `enq_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_failed_jobs`
--
ALTER TABLE `mpx_failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_faq`
--
ALTER TABLE `mpx_faq`
  MODIFY `faq_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_category_composition_allocations`
--
ALTER TABLE `mpx_fund_category_composition_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_classifications`
--
ALTER TABLE `mpx_fund_classifications`
  MODIFY `fc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_composition`
--
ALTER TABLE `mpx_fund_composition`
  MODIFY `fc_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_core`
--
ALTER TABLE `mpx_fund_core`
  MODIFY `ftm_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_detail`
--
ALTER TABLE `mpx_fund_detail`
  MODIFY `fd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_dictionary`
--
ALTER TABLE `mpx_fund_dictionary`
  MODIFY `fd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_man`
--
ALTER TABLE `mpx_fund_man`
  MODIFY `fm_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_master`
--
ALTER TABLE `mpx_fund_master`
  MODIFY `fund_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_scrips`
--
ALTER TABLE `mpx_fund_scrips`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_suggestion`
--
ALTER TABLE `mpx_fund_suggestion`
  MODIFY `fs_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_taxation`
--
ALTER TABLE `mpx_fund_taxation`
  MODIFY `ft_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_term`
--
ALTER TABLE `mpx_fund_term`
  MODIFY `ftm_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_type`
--
ALTER TABLE `mpx_fund_type`
  MODIFY `ft_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch`
--
ALTER TABLE `mpx_fund_watch`
  MODIFY `fw_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_disclaimer`
--
ALTER TABLE `mpx_fund_watch_disclaimer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_fund_composition_analyses`
--
ALTER TABLE `mpx_fund_watch_fund_composition_analyses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_graphs`
--
ALTER TABLE `mpx_fund_watch_graphs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_new`
--
ALTER TABLE `mpx_fund_watch_new`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_return_continious`
--
ALTER TABLE `mpx_fund_watch_return_continious`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_return_discontinious`
--
ALTER TABLE `mpx_fund_watch_return_discontinious`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_fund_watch_risk_ratios`
--
ALTER TABLE `mpx_fund_watch_risk_ratios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_composition`
--
ALTER TABLE `mpx_indices_composition`
  MODIFY `ic_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_corelation`
--
ALTER TABLE `mpx_indices_corelation`
  MODIFY `idc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_detail`
--
ALTER TABLE `mpx_indices_detail`
  MODIFY `idcd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_detail-15-10-2024`
--
ALTER TABLE `mpx_indices_detail-15-10-2024`
  MODIFY `idcd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_detail_03032025`
--
ALTER TABLE `mpx_indices_detail_03032025`
  MODIFY `idcd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_detail_19082025`
--
ALTER TABLE `mpx_indices_detail_19082025`
  MODIFY `idcd_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_indices_master`
--
ALTER TABLE `mpx_indices_master`
  MODIFY `idc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_jobs`
--
ALTER TABLE `mpx_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_know_the_ratio`
--
ALTER TABLE `mpx_know_the_ratio`
  MODIFY `ktr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_lates_from_plexus`
--
ALTER TABLE `mpx_lates_from_plexus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_mcap_eps`
--
ALTER TABLE `mpx_mcap_eps`
  MODIFY `me_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_media`
--
ALTER TABLE `mpx_media`
  MODIFY `media_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_menu`
--
ALTER TABLE `mpx_menu`
  MODIFY `menu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_menu_type`
--
ALTER TABLE `mpx_menu_type`
  MODIFY `menu_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_migrations`
--
ALTER TABLE `mpx_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_modules`
--
ALTER TABLE `mpx_modules`
  MODIFY `module_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_module_class`
--
ALTER TABLE `mpx_module_class`
  MODIFY `class_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_module_class_templates`
--
ALTER TABLE `mpx_module_class_templates`
  MODIFY `module_template_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_module_methods`
--
ALTER TABLE `mpx_module_methods`
  MODIFY `method_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_module_user_group_rights`
--
ALTER TABLE `mpx_module_user_group_rights`
  MODIFY `m_u_g_a_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_module_user_rel`
--
ALTER TABLE `mpx_module_user_rel`
  MODIFY `mur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_monthly_fund_house_performance`
--
ALTER TABLE `mpx_monthly_fund_house_performance`
  MODIFY `mfhp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_monthly_performance_synopses`
--
ALTER TABLE `mpx_monthly_performance_synopses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_monthly_ratio_calculations`
--
ALTER TABLE `mpx_monthly_ratio_calculations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_news`
--
ALTER TABLE `mpx_news`
  MODIFY `n_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_newsletter`
--
ALTER TABLE `mpx_newsletter`
  MODIFY `n_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_new_from_myplexus`
--
ALTER TABLE `mpx_new_from_myplexus`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_nfo_offer`
--
ALTER TABLE `mpx_nfo_offer`
  MODIFY `no_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_oauth_clients`
--
ALTER TABLE `mpx_oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_oauth_personal_access_clients`
--
ALTER TABLE `mpx_oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_options`
--
ALTER TABLE `mpx_options`
  MODIFY `option_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_pages`
--
ALTER TABLE `mpx_pages`
  MODIFY `page_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_payment_transactions`
--
ALTER TABLE `mpx_payment_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_personal_access_tokens`
--
ALTER TABLE `mpx_personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_plans`
--
ALTER TABLE `mpx_plans`
  MODIFY `p_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_risk_free`
--
ALTER TABLE `mpx_risk_free`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_risk_tolerance_portfolio_reg`
--
ALTER TABLE `mpx_risk_tolerance_portfolio_reg`
  MODIFY `portfolio_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_role_module_method_rights`
--
ALTER TABLE `mpx_role_module_method_rights`
  MODIFY `role_module_method_right_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_scrips`
--
ALTER TABLE `mpx_scrips`
  MODIFY `scrp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_subscriptions`
--
ALTER TABLE `mpx_subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_subscription_plans`
--
ALTER TABLE `mpx_subscription_plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_teams`
--
ALTER TABLE `mpx_teams`
  MODIFY `team_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_template`
--
ALTER TABLE `mpx_template`
  MODIFY `template_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_testimonial`
--
ALTER TABLE `mpx_testimonial`
  MODIFY `tmnl_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_users`
--
ALTER TABLE `mpx_users`
  MODIFY `u_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_group`
--
ALTER TABLE `mpx_user_group`
  MODIFY `u_g_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_group_pagedata_access`
--
ALTER TABLE `mpx_user_group_pagedata_access`
  MODIFY `u_g_pd_a_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_group_rel`
--
ALTER TABLE `mpx_user_group_rel`
  MODIFY `u_g_r_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_like`
--
ALTER TABLE `mpx_user_like`
  MODIFY `u_lk_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_sensitive_details`
--
ALTER TABLE `mpx_user_sensitive_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mpx_user_subscription`
--
ALTER TABLE `mpx_user_subscription`
  MODIFY `us_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `TmpRatioDataPerformance`
--
ALTER TABLE `TmpRatioDataPerformance`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `TmpRatioDataPerformanceVolatility`
--
ALTER TABLE `TmpRatioDataPerformanceVolatility`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `TmpRatioDataPerformanceVolatility_2`
--
ALTER TABLE `TmpRatioDataPerformanceVolatility_2`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `TmpRatioDataSchemeAlpha`
--
ALTER TABLE `TmpRatioDataSchemeAlpha`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

-- --------------------------------------------------------

--
-- Structure for view `cap_entry`
--
DROP TABLE IF EXISTS `cap_entry`;

DROP VIEW IF EXISTS `cap_entry`;
CREATE ALGORITHM=UNDEFINED DEFINER=`stm_user_lr`@`%` SQL SECURITY DEFINER VIEW `cap_entry`  AS WITH ranked_data AS (SELECT `mpx_mcap_eps`.`scrip_name` AS `scrip_name`, `mpx_mcap_eps`.`entry_date` AS `entry_date`, `mpx_mcap_eps`.`market_cap` AS `market_cap`, row_number() over ( order by `mpx_mcap_eps`.`market_cap` desc) AS `row_num` FROM `mpx_mcap_eps` WHERE `mpx_mcap_eps`.`entry_date` like '%2024-08%') SELECT `ranked_data`.`scrip_name` AS `scrip_name`, `ranked_data`.`entry_date` AS `entry_date`, `ranked_data`.`market_cap` AS `market_cap`, `ranked_data`.`row_num` AS `row_num`, CASE WHEN `ranked_data`.`row_num` between 1 and 15 THEN 'Very Large Cap' WHEN `ranked_data`.`row_num` between 16 and 100 THEN 'Large Cap' WHEN `ranked_data`.`row_num` between 101 and 250 THEN 'Mid Cap' ELSE 'Small Cap' END AS `cap_category` FROM `ranked_data` ORDER BY `ranked_data`.`market_cap` DESC LIMIT 0, 50005000  ;

-- --------------------------------------------------------

--
-- Structure for view `mpx_fund_composition_corpus_entry`
--
DROP TABLE IF EXISTS `mpx_fund_composition_corpus_entry`;

DROP VIEW IF EXISTS `mpx_fund_composition_corpus_entry`;
CREATE ALGORITHM=UNDEFINED DEFINER=`stm_user_lr`@`%` SQL SECURITY DEFINER VIEW `mpx_fund_composition_corpus_entry`  AS SELECT `mpx_corpus_entry`.`corpus_entry` AS `corpus_entry`, `mpx_corpus_entry`.`entry_date` AS `corpus_entry_date`, `mpx_fund_composition`.`fund_code` AS `fund_code`, `mpx_fund_composition`.`entry_date` AS `composition_entry_date`, `mpx_fund_composition`.`scrip_name` AS `scrip_name`, `mpx_fund_composition`.`industry` AS `industry`, `mpx_fund_composition`.`content_per` AS `content_per`, `mpx_fund_composition`.`content_per`* (`mpx_corpus_entry`.`corpus_entry` / 100) / 100 AS `calculated_amount`, `mpx_fund_composition`.`category` AS `category` FROM (`mpx_fund_composition` join `mpx_corpus_entry` on(`mpx_fund_composition`.`fund_code` = `mpx_corpus_entry`.`fund_code` and `mpx_fund_composition`.`entry_date` = `mpx_corpus_entry`.`entry_date`)) ;

-- --------------------------------------------------------

--
-- Structure for view `mpx_view_corpus_with_allocation`
--
DROP TABLE IF EXISTS `mpx_view_corpus_with_allocation`;

DROP VIEW IF EXISTS `mpx_view_corpus_with_allocation`;
CREATE ALGORITHM=UNDEFINED DEFINER=`stm_user_lr`@`%` SQL SECURITY DEFINER VIEW `mpx_view_corpus_with_allocation`  AS SELECT `mpx_corpus_entry`.`corpus_entry` AS `corpus_entry`, `mpx_corpus_entry`.`entry_date` AS `corpus_entry_date`, `mpx_fund_composition`.`fund_code` AS `fund_code`, `mpx_fund_composition`.`entry_date` AS `composition_entry_date`, `mpx_fund_composition`.`scrip_name` AS `scrip_name`, `mpx_fund_composition`.`industry` AS `industry`, `mpx_fund_composition`.`content_per` AS `content_per`, `mpx_fund_composition`.`content_per`* `mpx_corpus_entry`.`corpus_entry` / 100 AS `calculated_amount`, `mpx_fund_composition`.`category` AS `category` FROM (`mpx_fund_composition` join `mpx_corpus_entry` on(`mpx_fund_composition`.`fund_code` = `mpx_corpus_entry`.`fund_code`)) ;

-- --------------------------------------------------------

--
-- Structure for view `mpx_view_fund_nav_monthly_return`
--
DROP TABLE IF EXISTS `mpx_view_fund_nav_monthly_return`;

DROP VIEW IF EXISTS `mpx_view_fund_nav_monthly_return`;
CREATE ALGORITHM=UNDEFINED DEFINER=`stm_user_lr`@`%` SQL SECURITY DEFINER VIEW `mpx_view_fund_nav_monthly_return`  AS SELECT `dates`.`fund_code` AS `fund_code`, `dates`.`month_year` AS `month_year`, (`end_nav`.`closing_nav` - `start_nav`.`closing_nav`) / `start_nav`.`closing_nav` * 100 AS `nav_change_percentage` FROM (((select `mpx_fund_detail`.`fund_code` AS `fund_code`,date_format(`mpx_fund_detail`.`entry_date`,'%Y-%m') AS `month_year`,min(`mpx_fund_detail`.`entry_date`) AS `first_day_of_month`,max(`mpx_fund_detail`.`entry_date`) AS `last_day_of_month` from `mpx_fund_detail` group by `mpx_fund_detail`.`fund_code`,date_format(`mpx_fund_detail`.`entry_date`,'%Y-%m')) `dates` join `mpx_fund_detail` `start_nav` on(`dates`.`fund_code` = `start_nav`.`fund_code` and `dates`.`first_day_of_month` = `start_nav`.`entry_date`)) join `mpx_fund_detail` `end_nav` on(`dates`.`fund_code` = `end_nav`.`fund_code` and `dates`.`last_day_of_month` = `end_nav`.`entry_date`)) ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

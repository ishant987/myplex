<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;

use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Http\Request;
use DB;
use App\Models\FundMaster;
use App\Models\IndicesMaster;
use App\Models\CurrencyMaster;
use App\Models\FundType;
use App\Models\FundComposition;
use App\Models\IndicesComposition;
use App\Models\CorpusEntry;
use App\Models\MonthlyRatioCalculation;
use App\Models\FundDetail;
use App\Models\IndicesDetail;
use App\Models\FundMan;
use App\Models\CurrencyDetail;
use App\Models\RiskTolerancePortfolio;
use Carbon\Carbon;

use App\Lib\Core\Useful;
use App\Lib\Admin\App;
use App\Lib\Core\MailPS;
use Validator;
use Illuminate\Support\Str;
use Storage;


class CompareSchemeController extends BaseController
{
    public function getCompareRatios(Request $request)
    {
        $dataArr = $responseArr = [];
        $message = __('message');

        $compare_type = (isset($request->compare_type) && $request->compare_type) ? $request->compare_type : '';
        $value1 = (isset($request->value1) && $request->value1) ? urldecode($request->value1) : '';
        $value2 = (isset($request->value2) && $request->value2) ? urldecode($request->value2) : '';
        $value3 = (isset($request->value3) && $request->value3) ? urldecode($request->value3) : '';
        $value4 = (isset($request->value4) && $request->value4) ? urldecode($request->value4) : '';
        $value5 = (isset($request->value5) && $request->value5) ? urldecode($request->value5) : '';
        $value6 = (isset($request->value6) && $request->value6) ? urldecode($request->value6) : '';
        $from_date = (isset($request->from_date) && $request->from_date) ? $request->from_date : '';
        $to_date = (isset($request->to_date) && $request->to_date) ? $request->to_date : '';


        if ($compare_type && $value1 && $value2 && $from_date && $to_date) {
            $type1_first_date = '';
            $type2_first_date = '';

            $type1_first_date = FundDetail::getFirstPublishedDate($value1);

            $type2_first_date = FundDetail::getFirstPublishedDate($value2);
            $type3_first_date = FundDetail::getFirstPublishedDate($value3);
            $type4_first_date = FundDetail::getFirstPublishedDate($value4);
            $type5_first_date = FundDetail::getFirstPublishedDate($value5);
            $type6_first_date = FundDetail::getFirstPublishedDate($value6);

            $notice_text = '';
            $notice_value_type = '';

            if ($type1_first_date && $type2_first_date) {
                $dateTimestampFrom = strtotime($from_date);
                $dateTimestampType1 = strtotime($type1_first_date);
                $dateTimestampType2 = strtotime($type2_first_date);
                $dateTimestampType3 = strtotime($type3_first_date);
                $dateTimestampType4 = strtotime($type4_first_date);
                $dateTimestampType5 = strtotime($type5_first_date);
                $dateTimestampType6 = strtotime($type6_first_date);

                if ($dateTimestampFrom < $dateTimestampType1) {
                    $from_date = $type1_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType1);
                    $notice_value_type = '1';
                }
                if ($dateTimestampFrom < $dateTimestampType2) {
                    $from_date = $type2_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType2);
                    $notice_value_type = '2';
                }
                if ($dateTimestampFrom < $dateTimestampType3) {
                    $from_date = $type3_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType3);
                    $notice_value_type = '3';
                }
                if ($dateTimestampFrom < $dateTimestampType4) {
                    $from_date = $type4_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType4);
                    $notice_value_type = '4';
                }
                if ($dateTimestampFrom < $dateTimestampType5) {
                    $from_date = $type5_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType5);
                    $notice_value_type = '5';
                }
                if ($dateTimestampFrom < $dateTimestampType6) {
                    $from_date = $type6_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType6);
                    $notice_value_type = '6';
                }
            }
            $graphArr = [];
            if ($compare_type != 'rolling_return') {

                $graph1 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value1 . '")');
                $graphArr[0] = count($graph1) ? $graph1[0] : (object) [];
                $graph2 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value2 . '")');
                $graphArr[1] = count($graph2) ? $graph2[0] : (object) [];

                $graph3 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value3 . '")');
                $graphArr[2] = count($graph3) ? $graph3[0] : (object)[];

                $graph4 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value4 . '")');
                $graphArr[3] = count($graph4) ? $graph4[0] : (object)[];

                $graph5 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value5 . '")');
                $graphArr[4] = count($graph5) ? $graph5[0] : (object)[];

                $graph6 = DB::select('CALL sp_fund_ratios("' . $from_date . '","' . $to_date . '","' . $value6 . '")');
                $graphArr[5] = count($graph6) ? $graph6[0] : (object)[];
            } else {
                $graph1 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value1 . '")');
                $graphArr[0] = count($graph1) ? $graph1[0] : (object) [];

                $graph2 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value2 . '")');
                $graphArr[1] = count($graph2) ? $graph2[0] : (object) [];

                $graph3 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value3 . '")');
                $graphArr[2] = count($graph3) ? $graph3[0] : (object)[];

                $graph4 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value4 . '")');
                $graphArr[3] = count($graph4) ? $graph4[0] : (object)[];

                $graph5 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value5 . '")');
                $graphArr[4] = count($graph5) ? $graph5[0] : (object)[];

                $graph6 = DB::select('CALL sp_rolling_return("' . $from_date . '","' . $to_date . '","' . $value6 . '")');
                $graphArr[5] = count($graph6) ? $graph6[0] : (object)[];
            }

            $responseArr['graph_data'] = $graphArr;
            $responseArr['notice_text'] = $notice_text;
            $responseArr['notice_value_type'] = $notice_value_type;
            return $this->sendResponse($responseArr, __('api.success.api_dt_rtrv'));
        }
        return $this->sendError($message['data_not_available'], '');
    }
    public function getCompareComposition(Request $request)
    {
        $dataArr = $responseArr = [];
        $message = __('message');

        $compare_type = (isset($request->compare_type) && $request->compare_type) ? $request->compare_type : '';
        $value1 = (isset($request->value1) && $request->value1) ? urldecode($request->value1) : '';
        $value2 = (isset($request->value2) && $request->value2) ? urldecode($request->value2) : '';
        $value3 = (isset($request->value3) && $request->value3) ? urldecode($request->value3) : '';
        $value4 = (isset($request->value4) && $request->value4) ? urldecode($request->value4) : '';
        $value5 = (isset($request->value5) && $request->value5) ? urldecode($request->value5) : '';
        $value6 = (isset($request->value6) && $request->value6) ? urldecode($request->value6) : '';
        $month = (isset($request->month) && $request->month) ? $request->month : '';
        $year = (isset($request->year) && $request->year) ? $request->year : '';

        $inputDataArr=collect([$value1,$value2,$value3,$value4,$value5,$value6])->filter();

        if ($compare_type && $value1 && $value2 && $month && $year) {
            $type1_first_date = '';
            $type2_first_date = '';
            $type3_first_date = '';
            $type4_first_date = '';
            $type5_first_date = '';
            $type6_first_date = '';
            if ($compare_type == 'aaum') {
                $type1_first_date = CorpusEntry::getFirstPublishedDate($value1);

                $type2_first_date = CorpusEntry::getFirstPublishedDate($value2);
                $type3_first_date = $value3 ? CorpusEntry::getFirstPublishedDate($value3) : '';
                $type4_first_date = $value4 ?  CorpusEntry::getFirstPublishedDate($value4) : '';
                $type5_first_date = $value5 ? CorpusEntry::getFirstPublishedDate($value5) : '';
                $type6_first_date = $value6 ? CorpusEntry::getFirstPublishedDate($value6) : '';
            } else {
                $type1_first_date = FundComposition::getFirstPublishedDate($value1);

                $type2_first_date = FundComposition::getFirstPublishedDate($value2);
                $type3_first_date = $value3 ? FundComposition::getFirstPublishedDate($value3):'';
                $type4_first_date = $value4 ? FundComposition::getFirstPublishedDate($value4):'';
                $type5_first_date = $value5 ? FundComposition::getFirstPublishedDate($value5):'';
                $type6_first_date = $value6 ? FundComposition::getFirstPublishedDate($value6):'';
            }


            $notice_text = '';
            $notice_value_type = '';

            if ($type1_first_date && $type2_first_date) {
                $fdate = strtotime($year . '-' . $month . '-1');
                $from_date = date("Y-m-t", $fdate);
				
				
                $dateTimestampFrom = strtotime($from_date);
                $dateTimestampType1 = strtotime($type1_first_date);
                $dateTimestampType2 = strtotime($type2_first_date);

                if ($dateTimestampFrom < $dateTimestampType1) {
                    $from_date = $type1_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType1);
                    $notice_value_type = '1';
                }
                if ($dateTimestampFrom < $dateTimestampType2) {
                    $from_date = $type2_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType2);
                    $notice_value_type = '2';
                }
                if ($type3_first_date != '') {
                    $dateTimestampType3 = strtotime($type3_first_date);
                    if ($dateTimestampFrom < $dateTimestampType3) {
                        $from_date = $type3_first_date;
                        $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType3);
                        $notice_value_type = '3';
                    }
                }
                if ($type4_first_date != '') {
                    $dateTimestampType4 = strtotime($type4_first_date);
                    if ($dateTimestampFrom < $dateTimestampType4) {
                        $from_date = $type4_first_date;
                        $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType4);
                        $notice_value_type = '4';
                    }
                }
                if ($type5_first_date != '') {
                    $dateTimestampType5 = strtotime($type5_first_date);
                    if ($dateTimestampFrom < $dateTimestampType5) {
                        $from_date = $type5_first_date;
                        $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType5);
                        $notice_value_type = '5';
                    }
                }
                if ($type6_first_date != '') {
                    $dateTimestampType6 = strtotime($type6_first_date);
                    if ($dateTimestampFrom < $dateTimestampType6) {
                        $from_date = $type6_first_date;
                        $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType6);
                        $notice_value_type = '6';
                    }
                }
            } else {
                return $this->sendError($message['data_not_available'], '');
            }
            $graphArr = [];
            if ($compare_type == 'top_script') {
				
				//dd($from_date);
				
				$graph1 = DB::select('CALL sp_fund_search_portfolio_top_script("'.date("m", strtotime($from_date)).'","'.date("Y", strtotime($from_date)).'","'.$value1.'",10)');
                $graphArr['scheme1']['data'] = $graph1;
                $graphArr['scheme1']['top_scripts_sum'] = count($graph1) ? collect($graph1)->sum('content_per') : 'NA';
				
				if($value2 != "")
				{
						$graph2 = DB::select('CALL sp_fund_search_portfolio_top_script("'.date("m", strtotime($from_date)).'","'.date("Y", strtotime($from_date)).'","'.$value2.'",10)');
					$graphArr['scheme2']['data'] = $graph2;
					$graphArr['scheme2']['top_scripts_sum'] = count($graph2) ? collect($graph2)->sum('content_per') : 'NA';
				}
				
				if( $value3 != "" )
				{
					$graph3 = DB::select('CALL sp_fund_search_portfolio_top_script("'.date("m", strtotime($from_date)).'","'.date("Y", strtotime($from_date)).'","'.$value3.'",10)');
					$graphArr['scheme3']['data'] = $graph3;
					$graphArr['scheme3']['top_scripts_sum'] = count($graph3) ? collect($graph3)->sum('content_per') : 'NA';
				}
				
				if( $value4 != "" )
				{
					$graph4 = DB::select('CALL sp_fund_search_portfolio_top_script("'.date("m", strtotime($from_date)).'","'.date("Y", strtotime($from_date)).'","'.$value4.'",10)');
					$graphArr['scheme4']['data'] = $graph4;
					$graphArr['scheme4']['top_scripts_sum'] = count($graph4) ? collect($graph4)->sum('content_per') : 'NA';
				}
				
				if( $value5 != "" )
				{
					$graph5 = DB::select('CALL sp_fund_search_portfolio_top_script("'.date("m", strtotime($from_date)).'","'.date("Y", strtotime($from_date)).'","'.$value5.'",10)');
					$graphArr['scheme5']['data'] = $graph5;
					$graphArr['scheme5']['top_scripts_sum'] = count($graph5) ? collect($graph5)->sum('content_per') : 'NA';
				}
                
				
                /*foreach($inputDataArr as $key=>$value){
                    $graph1 = DB::select('CALL sp_fund_search_portfolio_top_script("' . date("m", strtotime($from_date)) . '","' . date("Y", strtotime($from_date)) . '","' . $value . '",10)');
					$fund_name =FundMaster::select('fund_name')->where('fund_code',$value)->first()->toArray();
                    $graphArr[$key]['data'] = $graph1;
					$graphArr[$key]['fund_name'] = $fund_name['fund_name'];
                    $graphArr[$key]['top_scripts_sum'] = count($graph1) ? collect($graph1)->sum('content_per') : 'NA';*/
					
					//dd($graphArr);
                
            } elseif ($compare_type == 'top_industry') {
                foreach($inputDataArr as $key=>$value){
                    $graph1 = DB::select('CALL sp_fund_search_portfolio_top_industry("' . date("m", strtotime($from_date)) . '","' . date("Y", strtotime($from_date)) . '","' . $value . '",10)');
					$fund_name =FundMaster::select('fund_name')->where('fund_code',$value)->first()->toArray();
                    $graphArr[$key]['data'] = $graph1;
					$graphArr[$key]['fund_name'] = $fund_name['fund_name'];
                    $graphArr[$key]['top_industry_sum'] = count($graph1) ? collect($graph1)->sum('content_per') : 'NA';
                }
            } else {
                foreach($inputDataArr as $key=>$value){
                    $graph1 = CorpusEntry::select(['fund_code', 'entry_date', 'corpus_entry'])->where('publish', 'y')->where('fund_code', $value)->where('entry_date', $from_date)->first();
					$fund_name =FundMaster::select('fund_name')->where('fund_code',$value)->first()->toArray();
						
                    $graphArr[$key]=$graph1!=null ? array_merge($graph1->toArray(),$fund_name) : $graph1;
                }
            }

            $responseArr['composition_data'] = $graphArr;
            $responseArr['notice_text'] = $notice_text;
            $responseArr['notice_value_type'] = $notice_value_type;
            return $this->sendResponse($responseArr, __('api.success.api_dt_rtrv'));
        }
        return $this->sendError($message['data_not_available'], '');
    }
    public function getComparePrice(Request $request)
    {
        //dd( $request->all() );

        $dataArr = $responseArr = [];
        $message = __('message');
        //$compare_type = (isset($request->compare_type) && $request->compare_type) ? $request->compare_type : '';
        $value1 = (isset($request->value1) && $request->value1) ? urldecode($request->value1) : '';
        $value2 = (isset($request->value2) && $request->value2) ? urldecode($request->value2) : '';
        $value3 = (isset($request->value3) && $request->value3) ? urldecode($request->value3) : '';
        $value4 = (isset($request->value4) && $request->value4) ? urldecode($request->value4) : '';
        $value5 = (isset($request->value5) && $request->value5) ? urldecode($request->value5) : '';
        $value6 = (isset($request->value6) && $request->value6) ? urldecode($request->value6) : '';
        $from_date = (isset($request->from_date) && $request->from_date) ? $request->from_date : '';
        $to_date = (isset($request->to_date) && $request->to_date) ? $request->to_date : '';

        /*$from_date = '2022-04-19';
        $to_date = '2023-04-19';*/

       // $typeArr = explode("_", $compare_type);

        $type1_first_date = '';
        $type2_first_date = '';
        $type3_first_date = '';
        $type4_first_date = '';
        $type5_first_date = '';
        $type6_first_date = '';

        $type1 = '';
        $type2 = '';
        $type3 = '';
        $type4 = '';
        $type5 = '';

        $compare1 = [];
        $compare2 = [];
        $compare3 = [];
        $compare4 = [];
        $compare5 = [];

        if( $request->compare1 != "" )
        {
            $compare1 = explode('_',  $request->compare1);            

            if (count($compare1) == 2 && $value1 && $value2 && $from_date && $to_date) {                

                if ($compare1[0] == 'scheme') {
                    $type1_first_date = FundDetail::getFirstPublishedDate($value1);                    
                    $type1 = 'GRAPH_FUND';
                }
                if ($compare1[0] == 'index') {
                    $type1_first_date = IndicesDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_INDEX';
                }
                if ($compare1[0] == 'currency') {
                    $type1_first_date = CurrencyDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_CURRENCY';
                }

                if ($compare1[1] == 'scheme') {
                    $type2_first_date = FundDetail::getFirstPublishedDate($value2);
                    $type2 = 'GRAPH_FUND';
                }
                if ($compare1[1] == 'index') {
                    $type2_first_date = IndicesDetail::getFirstPublishedDate($value2);
                    $type2 = 'GRAPH_INDEX';
                }
                if ($compare1[1] == 'currency') {
                    $type2_first_date = CurrencyDetail::getFirstPublishedDate($value2);
                    $type2 = 'GRAPH_CURRENCY';
                }

            }
        }

        if( $request->compare2 != "" )
        {
            $compare2 = explode('_',  $request->compare2);

            if (count($compare2) == 2 && $value1 && $value3 && $from_date && $to_date) {

                if ($compare2[0] == 'scheme') {
                    $type1_first_date = FundDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_FUND';                    
                }
                if ($compare2[0] == 'index') {
                    $type1_first_date = IndicesDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_INDEX';                   
                }
                if ($compare2[0] == 'currency') {
                    $type1_first_date = CurrencyDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_CURRENCY';                    
                }

                if ($compare2[1] == 'scheme') {
                    $type3_first_date = FundDetail::getFirstPublishedDate($value3);
                    $type3 = 'GRAPH_FUND';
                }
                if ($compare2[1] == 'index') {
                    $type3_first_date = IndicesDetail::getFirstPublishedDate($value3);
                    $type3 = 'GRAPH_INDEX';
                }
                if ($compare2[1] == 'currency') {
                    $type3_first_date = CurrencyDetail::getFirstPublishedDate($value3);
                    $type3 = 'GRAPH_CURRENCY';
                }

            }
        }

        if( $request->compare3 != "" )
        {
            $compare3 = explode('_',  $request->compare3);

            if (count($compare3) == 2 && $value1 && $value4 && $from_date && $to_date) {

                if ($compare3[0] == 'scheme') {
                    $type1_first_date = FundDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_FUND'; 
                }
                if ($compare3[0] == 'index') {
                    $type1_first_date = IndicesDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_INDEX'; 
                }
                if ($compare3[0] == 'currency') {
                    $type1_first_date = CurrencyDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_CURRENCY';
                }


                if ($compare3[1] == 'scheme') {
                    $type4_first_date = FundDetail::getFirstPublishedDate($value4);
                    $type4 = 'GRAPH_FUND';
                }
                if ($compare3[1] == 'index') {
                    $type4_first_date = IndicesDetail::getFirstPublishedDate($value4);
                    $type4 = 'GRAPH_INDEX';
                }
                if ($compare3[1] == 'currency') {
                    $type4_first_date = CurrencyDetail::getFirstPublishedDate($value4);
                    $type4 = 'GRAPH_CURRENCY';
                }

            }
        }


        if( $request->compare4 != "" )
        {
            $compare4 = explode('_',  $request->compare4);

            if (count($compare4) == 2 && $value1 && $value5 && $from_date && $to_date) {

                if ($compare4[0] == 'scheme') {
                    $type1_first_date = FundDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_FUND';
                }
                if ($compare4[0] == 'index') {
                    $type1_first_date = IndicesDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_INDEX';
                }
                if ($compare4[0] == 'currency') {
                    $type1_first_date = CurrencyDetail::getFirstPublishedDate($value1);
                    $type1 = 'GRAPH_CURRENCY';
                }

                if ($compare4[1] == 'scheme') {
                    $type5_first_date = FundDetail::getFirstPublishedDate($value5);
                    $type5 = 'GRAPH_FUND';
                }
                if ($compare4[1] == 'index') {
                    $type5_first_date = IndicesDetail::getFirstPublishedDate($value5);
                    $type5 = 'GRAPH_INDEX';
                }
                if ($compare4[1] == 'currency') {
                    $type5_first_date = CurrencyDetail::getFirstPublishedDate($value5);
                    $type5 = 'GRAPH_CURRENCY';
                }

            }
        }

            $notice_text = '';
            $notice_value_type = '';            

            if ($type1_first_date && $type2_first_date || $type1_first_date && $type3_first_date || $type1_first_date && $type4_first_date || $type1_first_date && $type5_first_date) {

                $dateTimestampFrom = strtotime($from_date);
                $dateTimestampType1 = strtotime($type1_first_date);
                $dateTimestampType2 = strtotime($type2_first_date);
                $dateTimestampType3 = strtotime($type3_first_date);
                $dateTimestampType4 = strtotime($type4_first_date);
                $dateTimestampType5 = strtotime($type5_first_date);
                //$dateTimestampType6 = strtotime($type6_first_date);

                if ($dateTimestampFrom < $dateTimestampType1) {
                    $from_date = $type1_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType1);
                    $notice_value_type = '1';
                }
                if ($dateTimestampFrom < $dateTimestampType2) {
                    $from_date = $type2_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType2);
                    $notice_value_type = '2';
                }
                if ($dateTimestampFrom < $dateTimestampType3) {
                    $from_date = $type3_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType3);
                    $notice_value_type = '3';
                }
                if ($dateTimestampFrom < $dateTimestampType4) {
                    $from_date = $type4_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType4);
                    $notice_value_type = '4';
                }
                if ($dateTimestampFrom < $dateTimestampType5) {
                    $from_date = $type5_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType5);
                    $notice_value_type = '5';
                }
                /* if ($dateTimestampFrom < $dateTimestampType6) {
                    $from_date = $type6_first_date;
                    $notice_text = 'data available from ' . date('d/m/Y', $dateTimestampType6);
                    $notice_value_type = '6';
                } */
            
                $graphArr = [];				
					
                
                $graphArr[0] = DB::select('CALL sp_fund_index_currency("' . $type1 . '","' . $from_date . '","' . $to_date . '",0,"' . $value1 . '","","",0)');
				//dd($graphArr[0]);
                $graphArr[1] = DB::select('CALL sp_fund_index_currency("' . $type2 . '","' . $from_date . '","' . $to_date . '",0,"' . $value2 . '","","",0)');
                $graphArr[2] = DB::select('CALL sp_fund_index_currency("' . $type3 . '","' . $from_date . '","' . $to_date . '",0,"' . $value3 . '","","",0)');
				
                $graphArr[3] = DB::select('CALL sp_fund_index_currency("' . $type4 . '","' . $from_date . '","' . $to_date . '",0,"' . $value4 . '","","",0)');
				
                $graphArr[4] = DB::select('CALL sp_fund_index_currency("' . $type5 . '","' . $from_date . '","' . $to_date . '",0,"' . $value5 . '","","",0)');
				
				
                //$graphArr[5] = DB::select('CALL sp_fund_index_currency("' . $type2 . '","' . $from_date . '","' . $to_date . '",0,"' . $value6 . '","","",0)');
                $responseArr['graph_data'] = $graphArr;
                $responseArr['notice_text'] = $notice_text;
                $responseArr['notice_value_type'] = $notice_value_type;
                $responseArr['notice_value_type_text'] = $value3;
                return $this->sendResponse($responseArr, __('api.success.api_dt_rtrv'));
            }
        
        return $this->sendError($message['data_not_available'], '');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\admin\blogCreate;
use Illuminate\Support\Facades\Auth;
use App\Models\BlogModel;
use App\Models\MediaModel;
use Validator;
use App\Lib\Core\Core;
use App\Lib\Admin\App;
use Illuminate\Database\QueryException;

class BlogController extends BaseController
{

     public function __construct()
     {
          
          $classNameArr = explode('\\', __CLASS__);
          $this->className = end($classNameArr);
          $this->admin = Auth::guard('admin')->user();
     }

     public function index()
     {

          $blogs = BlogModel::with('creator')->orderBy('created_at','desc')->get();
          $coreObj = new App();
          $listDataAtrArr = $coreObj->getListDataAtr();
          $statusAtrArr = $coreObj->getStatusLblTyp2Atr();
          
        $roleRights = ['add' => App::hasAccessToMethod($this->className, 'admin.blog.create'), 'edit' => App::hasAccessToMethod($this->className, 'admin.blog.edit'), 'delete' => App::hasAccessToMethod($this->className, 'admin.blog.delete')];
          return view("themes.backend.pages.blog.index", compact('blogs', 'statusAtrArr', 'listDataAtrArr','roleRights'));
     }

     public function create()
     {
          $adminID = Auth::guard('admin')->user()->admin_id;
          $data = ['adminID' => $adminID];
          $firstName = Auth::guard('admin')->user()['first_name'];
          return view("themes.backend.pages.blog.create", compact('data', 'firstName'));
     }

     public function edit($id)
     {

          $blog = BlogModel::findOrFail($id);

          $coreObj = new App();
          $listDataAtrArr = $coreObj->getListDataAtr();
          $statusAtrArr = $coreObj->getStatusLblTyp2Atr();


          return view("themes.backend.pages.blog.update", compact('blog'));
     }

     private function cleanUrl($string)
     {
          $str_url = strtolower(preg_replace('/-+/', '-', preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '-', $string))));
          if ($str_url == '-') {
               return uniqid(6) . uniqid(3);
          }
          return $str_url;
     }


     public function store(blogCreate $request, $id = '')
     {
          $params = $request->input();
          $isActivated = $params['is_active'] == '1' ? 1 : null;
          $curTime = new \DateTime();
          $published_time = $curTime->format("Y-m-d H:i:s");
          $params['published_by'] = $isActivated;
          $params['published_date'] = !is_null($isActivated) ? $published_time : null;
          $params['created_by'] = $params['updated_id'] = Auth::guard('admin')->user()['admin_id'];
          $params['status'] = $params['is_active'];
          $params['unique_url'] = SELF::cleanUrl($params['heading']);
          $params['image_thumb'] = SELF::getImage($request->file('image_thumb'),$request->input('image_thumb_old'));
          $params['image_banner'] = SELF::getImage($request->file('image_banner'),$request->input('image_banner_old'));


          BlogModel::updateOrCreate(
               [
                    //  check data with the existing db data (e.g) id
                    'id' => $id,
               ],

               $params

          );

          return redirect(route('admin.blog.index'));
     }
     private function getImage($file,$old_image){
          $name =SELF::fileUpload($file);
          if($name ==null ){
              return  $old_image !='' ? $old_image : null;
          }else{
              return $name;
          }
          
      }
     private function fileUpload($file)
     {
          if(isset($file)){
               $upldDirName = Config('commonconstants.blog_dir_name');
               $title     = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
               $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
               $filename  = time() . '-' . Core::removeSpecialChars($title) . '.' . $extension;
               $path      = $file->storeAs($upldDirName, $filename);
               return $filename;
          }
         else{
               return null;
         }
     }

     public function delete(Request $request){

          
        $loginAdminId = self::getLoggedInAdminId();
        $commonconstants = Config('commonconstants');
        try {
             $checkboxArr = $request->get('checkbox');
             if (count($checkboxArr)) {
                  BlogModel::whereIn('id', $checkboxArr)->delete();
            }
        } catch (QueryException $exception) {
            if ($loginAdminId == $commonconstants['def_super_admin_id']) {
                return back()->with('alert', Config('adminconstants.alert_css.2'))->with('message', $exception->getMessage())->with('title', __('admin.error_ttl'))->withInput();
            } else {
                return back()->with('alert', Config('adminconstants.alert_css.2'))->with('message', __('message.error.delete'))->with('title', __('admin.error_ttl'));
            }
        }

        return back()->with('alert', Config('adminconstants.alert_css.1'))->with('message', __('message.success.delete'))->with('title', __('admin.success_ttl'));
          
     }

     public function comments($id){
          $blogComments = BlogModel::with('comments')->find($id)->toArray();
          $coreObj = new App();
          $listDataAtrArr = $coreObj->getListDataAtr();
          $statusAtrArr = $coreObj->getStatusLblTyp2Atr();
          return view("themes.backend.pages.blogComments.index", compact('blogComments', 'statusAtrArr', 'listDataAtrArr'));
          
     }
     
     
}

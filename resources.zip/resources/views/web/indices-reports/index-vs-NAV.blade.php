@extends('web.layout.infosolz_user_app')

@section('content')
    <div class="inner_main">
        <div class="page_detail">
            <div class="inner_padding">
                <div class="head_brdcm">
                    <ul class="brdcmb">
                        <li><a href="{{ route('user.auth-dashboard') }}">dashboard</a></li>
                        <li><a href="{{ route('user.indices_report') }}">indices report</a></li>
                        <li>Index vs NAV</li>
                    </ul>
                </div>
                <div class="new_page">
                    <a href="#" class="back_btn"><i class="fa-solid fa-arrow-left"></i></a>
                    <div class="perform_head">
                        <h2>Index vs NAV</h2>
                    </div>
                    <form action="" method="get">
                        <div class="index_nav">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="nav_in">
                                        <div class="wm_tab">
                                            <ul class="">
                                                <li>
                                                    <a href="javascript:void(0)" id="main_select_scheme"
                                                        onclick="main_select('scheme')"
                                                        class="{{ (isset($request['main_select']) && $request['main_select'] == 'scheme') || !isset($request['main_select']) ? 'active' : '' }}">Schemes</a>
                                                    <input type="hidden" id="main_select" name="main_select"
                                                        value="{{ isset($request['main_select']) ? $request['main_select'] : '' }}">
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)" id="main_select_index"
                                                        onclick="main_select('index')"
                                                        class="{{ isset($request['main_select']) && $request['main_select'] == 'index' ? 'active' : '' }}">Index</a>
                                                </li>



                                            </ul>
                                        </div>

                                        <div class="">

                                            <div id="main_scheme" class="tab"
                                                style="{{ isset($request['main_select']) && $request['main_select'] == 'index' ? 'display:none' : '' }}">
                                                <div class="form_group">
                                                    <select name="scheme_main" class="select2"
                                                        data-placeholder="Select Scheme" onchange="main_drpdown('scheme')">
                                                        <option value="">Select Scheme</option>
                                                        @isset($schemes)
                                                            @foreach ($schemes as $scheme)
                                                                <option value="{{ $scheme->fund_code }}"
                                                                    @if (isset($request['scheme_main']) && $scheme->fund_code == $request['scheme_main']) selected @endif>
                                                                    {{ $scheme->fund_name }}</option>
                                                            @endforeach
                                                        @endisset
                                                    </select>
                                                </div>
                                            </div>

                                            <div id="main_index" class="tab"
                                                style="{{ (isset($request['main_select']) && $request['main_select'] == 'scheme') || !isset($request['main_select']) ? 'display:none' : '' }}">
                                                <div class="form_group">
                                                    <select name="index_main" class="select2"
                                                        data-placeholder="Select Index" onchange="main_drpdown('index')">
                                                        <option value="">Select Index</option>
                                                        @isset($indices)
                                                            @foreach ($indices as $index)
                                                                <option value="{{ $index->corelation }}"
                                                                    @if (isset($request['index_main']) && $index->corelation == $request['index_main']) selected @endif>
                                                                    {{ $index->name }}</option>
                                                            @endforeach
                                                        @endisset
                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row date_sec">
                                        <div class="col-md-6">
                                            <label>From date</label>
                                            <div class="form_group">
                                                <input type="text" name="from_date" class="datepicker"
                                                    value="{{ isset($request['from_date']) ? $request['from_date'] : '' }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label>To date</label>
                                            <div class="form_group">
                                                <input type="text" name="to_date" class="datepicker"
                                                    value="{{ isset($request['to_date']) ? $request['to_date'] : '' }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="index_five">

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_1('scheme')"
                                                            id="select_scheme_1"
                                                            class="{{ (isset($request['select_1']) && $request['select_1'] == 'scheme') || !isset($request['select_1']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_1" name="select_1"
                                                            value="{{ isset($request['select_1']) ? $request['select_1'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_1('index')"
                                                            id="select_index_1"
                                                            class="{{ isset($request['select_1']) && $request['select_1'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>

                                                </ul>
                                            </div>

                                            <div class="tabsct">

                                                <div id="scheme_1" class=""
                                                    style="{{ isset($request['select_1']) && $request['select_1'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_1" class="select2"
                                                            data-placeholder="Select Scheme" onchange="drpdown_1('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_1']) && $scheme->fund_code == $request['scheme_1']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="" id="index_1"
                                                    style="{{ (isset($request['select_1']) && $request['select_1'] == 'scheme') || !isset($request['select_1']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_1" class="select2"
                                                            onchange="drpdown_1('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_1']) && $index->corelation == $request['index_1']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_2('scheme')"
                                                            id="select_scheme_2"
                                                            class="{{ (isset($request['select_2']) && $request['select_2'] == 'scheme') || !isset($request['select_2']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_2" name="select_2"
                                                            value="{{ isset($request['select_2']) ? $request['select_2'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_2('index')"
                                                            id="select_index_2"
                                                            class="{{ isset($request['select_2']) && $request['select_2'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>
                                                </ul>

                                            </div>

                                            <div class="tabsct">
                                                <div class="" id="scheme_2"
                                                    style="{{ isset($request['select_2']) && $request['select_2'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_2" class="select2"
                                                            data-placeholder="Select Scheme"
                                                            onchange="drpdown_2('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_2']) && $scheme->fund_code == $request['scheme_2']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="" id="index_2"
                                                    style="{{ (isset($request['select_2']) && $request['select_2'] == 'scheme') || !isset($request['select_2']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_2" class="select2"
                                                            onchange="drpdown_2('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_2']) && $index->corelation == $request['index_2']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- ===============3========= --}}

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_3('scheme')"
                                                            id="select_scheme_3"
                                                            class="{{ (isset($request['select_3']) && $request['select_3'] == 'scheme') || !isset($request['select_3']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_3" name="select_3"
                                                            value="{{ isset($request['select_3']) ? $request['select_3'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_3('index')"
                                                            id="select_index_3"
                                                            class="{{ isset($request['select_3']) && $request['select_3'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>
                                                </ul>

                                            </div>

                                            <div class="tabsct">
                                                <div class="" id="scheme_3"
                                                    style="{{ isset($request['select_3']) && $request['select_3'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_3" class="select2"
                                                            data-placeholder="Select Scheme"
                                                            onchange="drpdown_3('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_3']) && $scheme->fund_code == $request['scheme_3']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="" id="index_3"
                                                    style="{{ (isset($request['select_3']) && $request['select_3'] == 'scheme') || !isset($request['select_3']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_3" class="select2"
                                                            onchange="drpdown_3('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_3']) && $index->corelation == $request['index_3']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- ===============4========= --}}

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_4('scheme')"
                                                            id="select_scheme_4"
                                                            class="{{ (isset($request['select_4']) && $request['select_4'] == 'scheme') || !isset($request['select_4']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_4" name="select_4"
                                                            value="{{ isset($request['select_4']) ? $request['select_4'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_4('index')"
                                                            id="select_index_4"
                                                            class="{{ isset($request['select_4']) && $request['select_4'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>
                                                </ul>

                                            </div>

                                            <div class="tabsct">
                                                <div class="" id="scheme_4"
                                                    style="{{ isset($request['select_4']) && $request['select_4'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_4" class="select2"
                                                            data-placeholder="Select Scheme"
                                                            onchange="drpdown_4('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_4']) && $scheme->fund_code == $request['scheme_4']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="" id="index_4"
                                                    style="{{ (isset($request['select_4']) && $request['select_4'] == 'scheme') || !isset($request['select_4']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_4" class="select2"
                                                            onchange="drpdown_4('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_4']) && $index->corelation == $request['index_4']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- ===============5========= --}}

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_5('scheme')"
                                                            id="select_scheme_5"
                                                            class="{{ (isset($request['select_5']) && $request['select_5'] == 'scheme') || !isset($request['select_5']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_5" name="select_5"
                                                            value="{{ isset($request['select_5']) ? $request['select_5'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_5('index')"
                                                            id="select_index_5"
                                                            class="{{ isset($request['select_5']) && $request['select_5'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>
                                                </ul>

                                            </div>

                                            <div class="tabsct">
                                                <div class="" id="scheme_5"
                                                    style="{{ isset($request['select_5']) && $request['select_5'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_5" class="select2"
                                                            data-placeholder="Select Scheme"
                                                            onchange="drpdown_5('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_5']) && $scheme->fund_code == $request['scheme_5']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="" id="index_5"
                                                    style="{{ (isset($request['select_5']) && $request['select_5'] == 'scheme') || !isset($request['select_5']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_5" class="select2"
                                                            onchange="drpdown_5('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_5']) && $index->corelation == $request['index_5']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- ===============6========= --}}

                                        <div class="single_index">
                                            <div class="wm_tab">
                                                <ul class="">
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_6('scheme')"
                                                            id="select_scheme_6"
                                                            class="{{ (isset($request['select_6']) && $request['select_6'] == 'scheme') || !isset($request['select_6']) ? 'active' : '' }}">Schemes</a>
                                                        <input type="hidden" id="select_6" name="select_6"
                                                            value="{{ isset($request['select_6']) ? $request['select_6'] : '' }}">
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" onclick="select_6('index')"
                                                            id="select_index_6"
                                                            class="{{ isset($request['select_6']) && $request['select_6'] == 'index' ? 'active' : '' }}">Index</a>
                                                    </li>
                                                </ul>

                                            </div>

                                            <div class="tabsct">
                                                <div class="" id="scheme_6"
                                                    style="{{ isset($request['select_6']) && $request['select_6'] == 'index' ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="scheme_6" class="select2"
                                                            data-placeholder="Select Scheme"
                                                            onchange="drpdown_6('scheme')">
                                                            <option value="">Select Scheme</option>
                                                            @isset($schemes)
                                                                @foreach ($schemes as $scheme)
                                                                    <option value="{{ $scheme->fund_code }}"
                                                                        @if (isset($request['scheme_6']) && $scheme->fund_code == $request['scheme_6']) selected @endif>
                                                                        {{ $scheme->fund_name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="" id="index_6"
                                                    style="{{ (isset($request['select_6']) && $request['select_6'] == 'scheme') || !isset($request['select_6']) ? 'display:none' : '' }}">
                                                    <div class="form_group">
                                                        <select name="index_6" class="select2"
                                                            onchange="drpdown_6('index')">
                                                            <option value="">Select Index</option>
                                                            @isset($indices)
                                                                @foreach ($indices as $index)
                                                                    <option value="{{ $index->corelation }}"
                                                                        @if (isset($request['index_6']) && $index->corelation == $request['index_6']) selected @endif>
                                                                        {{ $index->name }}</option>
                                                                @endforeach
                                                            @endisset
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="bttn_grp">
                                        <input type="hidden" id="indices_graph_1"
                                            value="{{ isset($indices_vals_1) ? json_encode($indices_vals_1) : '' }}">
                                        <input type="hidden" id="indices_graph_2"
                                            value="{{ isset($indices_vals_2) ? json_encode($indices_vals_2) : '' }}">
                                        <input type="hidden" id="indices_graph_3"
                                            value="{{ isset($indices_vals_3) ? json_encode($indices_vals_3) : '' }}">
                                        <input type="hidden" id="indices_graph_4"
                                            value="{{ isset($indices_vals_4) ? json_encode($indices_vals_4) : '' }}">
                                        <input type="hidden" id="indices_graph_5"
                                            value="{{ isset($indices_vals_5) ? json_encode($indices_vals_5) : '' }}">
                                        <input type="hidden" id="indices_graph_6"
                                            value="{{ isset($indices_vals_6) ? json_encode($indices_vals_6) : '' }}">


                                        <button class="btn btn-success" type="submit">Compare</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    
                    @if (isset($indices_vals_1) || isset($request['scheme_2']) || isset($request['scheme_3']) || isset($request['scheme_4']) || isset($request['scheme_5']) || isset($request['scheme_6'])   )
                    <div class="share_pdf">
                        <div class="sharethis-inline-share-buttons" ></div>
                        {{-- <a href="javascript:void(0)" id="exportPDF" class="pdf"><img
                                src="{{ asset('themes/frontend/assets/infosolz/images/pdf.png') }}"></a> --}}

                    </div>
                    @endif

                    @if (isset($indices_vals_1) && count($indices_vals_1) != 0)
                        <div class="graph_section">
                            <div id="chartContainer_1" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @else
                        <div class="graph_section">
                            <p style="text-align: center;">Please search above to show the results</p>
                        </div>
                    @endif

                    @if(isset($request['scheme_2']) && !empty($request['scheme_2']) || isset($request['index_2']) && !empty($request['index_2']))
                        <div class="graph_section">
                            <div id="chartContainer_2" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @endif

                    @if(isset($request['scheme_3']) && !empty($request['scheme_3']) || isset($request['index_3']) && !empty($request['index_3']))
                        <div class="graph_section">
                            <div id="chartContainer_3" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @endif

                    @if(isset($request['scheme_4']) && !empty($request['scheme_4']) || isset($request['index_4']) && !empty($request['index_4']))
                        <div class="graph_section">
                            <div id="chartContainer_4" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @endif

                    @if(isset($request['scheme_5']) && !empty($request['scheme_5']) || isset($request['index_5']) && !empty($request['index_5']))
                        <div class="graph_section">
                            <div id="chartContainer_5" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @endif

                    @if(isset($request['scheme_6']) && !empty($request['scheme_6']) || isset($request['index_6']) && !empty($request['index_6']))
                        <div class="graph_section">
                            <div id="chartContainer_6" style="height: 500px; width: 100%; margin-bottom: 20px;"></div>
                        </div>
                    @endif


                </div>
                @if (isset($indices_vals_6))
                <div class="disclaimer">
                    <p><strong>Disclaimer : </strong>{{ $disclaimer }}</p>
                </div>
              @endif
            </div>
        </div>

    </div>

    <script>
        function main_select(val) {
            // alert(val);

            $("#main_select").val(val);
            if (val == 'index') {
                $("#main_index").show();
                $("#main_select_index").addClass('active');
                $("#main_select_scheme").removeClass('active');
                $("#main_scheme").hide();
            } else {
                $("#main_scheme").show();
                $("#main_select_index").removeClass('active');
                $("#main_select_scheme").addClass('active');
                $("#main_index").hide();
            }

        }

        function select_1(val) {
            // alert(val);
            $("#select_1").val(val);
            if (val == 'index') {
                $("#index_1").show();
                $("#select_index_1").addClass('active');
                $("#select_scheme_1").removeClass('active');
                $("#scheme_1").hide();
            } else {
                $("#scheme_1").show();
                $("#select_index_1").removeClass('active');
                $("#select_scheme_1").addClass('active');
                $("#index_1").hide();
            }
        }

        function select_2(val) {
            // alert("select 2");
            $("#select_2").val(val);
            if (val == 'index') {
                $("#index_2").show();
                $("#select_index_2").addClass('active');
                $("#select_scheme_2").removeClass('active');
                $("#scheme_2").hide();
            } else {
                $("#scheme_2").show();
                $("#select_index_2").removeClass('active');
                $("#select_scheme_2").addClass('active');
                $("#index_2").hide();
            }
        }

        function select_3(val) {
            // alert("select 3");
            $("#select_3").val(val);
            if (val == 'index') {
                $("#index_3").show();
                $("#select_index_3").addClass('active');
                $("#select_scheme_3").removeClass('active');
                $("#scheme_3").hide();
            } else {
                $("#scheme_3").show();
                $("#select_index_3").removeClass('active');
                $("#select_scheme_3").addClass('active');
                $("#index_3").hide();
            }
        }

        function select_4(val) {
            // alert(val);
            $("#select_4").val(val);
            if (val == 'index') {
                $("#index_4").show();
                $("#select_index_4").addClass('active');
                $("#select_scheme_4").removeClass('active');
                $("#scheme_4").hide();
            } else {
                $("#scheme_4").show();
                $("#select_index_4").removeClass('active');
                $("#select_scheme_4").addClass('active');
                $("#index_4").hide();
            }
        }

        function select_5(val) {
            // alert(val);
            $("#select_5").val(val);
            if (val == 'index') {
                $("#index_5").show();
                $("#select_index_5").addClass('active');
                $("#select_scheme_5").removeClass('active');
                $("#scheme_5").hide();
            } else {
                $("#scheme_5").show();
                $("#select_index_5").removeClass('active');
                $("#select_scheme_5").addClass('active');
                $("#index_5").hide();
            }
        }

        function select_6(val) {
            // alert(val);
            $("#select_6").val(val);
            if (val == 'index') {
                $("#index_6").show();
                $("#select_index_6").addClass('active');
                $("#select_scheme_6").removeClass('active');
                $("#scheme_6").hide();
            } else {
                $("#scheme_6").show();
                $("#select_index_6").removeClass('active');
                $("#select_scheme_6").addClass('active');
                $("#index_6").hide();
            }
        }

        function main_drpdown(val) {
            if (val == 'index') {
                $("#main_select").val('index');
            } else if (val == 'scheme') {
                $("#main_select").val('scheme');
            }
        }

        function drpdown_1(val) {
            if (val == 'index') {
                $("#select_1").val('index');
            } else if (val == 'scheme') {
                $("#select_1").val('scheme');
            }
        }

        function drpdown_2(val) {
            if (val == 'index') {
                $("#select_2").val('index');
            } else if (val == 'scheme') {
                $("#select_2").val('scheme');
            }
        }

        function drpdown_3(val) {
            if (val == 'index') {
                $("#select_3").val('index');
            } else if (val == 'scheme') {
                $("#select_3").val('scheme');
            }
        }

        function drpdown_4(val) {
            if (val == 'index') {
                $("#select_4").val('index');
            } else if (val == 'scheme') {
                $("#select_4").val('scheme');
            }
        }

        function drpdown_5(val) {
            if (val == 'index') {
                $("#select_5").val('index');
            } else if (val == 'scheme') {
                $("#select_5").val('scheme');
            }
        }

        function drpdown_6(val) {
            if (val == 'index') {
                $("#select_6").val('index');
            } else if (val == 'scheme') {
                $("#select_6").val('scheme');
            }
        }
    </script>


    <!-- Highcharts library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>


    <script>
        $(document).ready(function() {
            function initializeChart(graphId, containerId) {
                let indicesGraphData = document.getElementById(graphId).value;

                if (indicesGraphData !== '') {
                    try {
                        indicesGraphData = JSON.parse(indicesGraphData);

                        let seriesData = [];

                        var graph_data1_date = ['2023-01-01', '2023-02-01', '2023-03-01', '2023-04-01',
                            '2023-05-01'
                        ];
                        var graph_data1_value = [65, 59, 80, 81, 56];
                        var graph_data2_date = ['2023-01-01', '2023-02-01', '2023-03-01', '2023-04-01',
                            '2023-05-01'
                        ];
                        var graph_data2_value = [28, 48, 40, 19, 86];

                        var index_name = [];
                        var graph_data_date = [];
                        var graph_data_value = [];

                        // Prepare series data for each index
                        for (let index in indicesGraphData) {

                            if (indicesGraphData.hasOwnProperty(index)) {

                                index_name.push(index);

                                graph_data_date[index] = [];
                                graph_data_value[index] = [];

                                indicesGraphData[index].forEach((item) => {

                                    let date = new Date(item[0]).getTime();
                                    let value = parseFloat(item[1]);

                                    graph_data_date[index].push(date);
                                    graph_data_value[index].push(value);
                                });

                            }
                        }

                        // console.log('graph_data_date', graph_data_date[index_name[0]]);
                        // console.log('graph_data_value', graph_data_value);

                        Highcharts.chart(containerId, {
                            accessibility: {
                                enabled: false
                            },
                            chart: {
                                type: 'spline',
                                zoomType: 'xy'
                            },

                            title: {
                                text: ''
                            },

                            xAxis: {
                                type: 'datetime',
                                labels: {
                                    formatter: function() {
                                        return Highcharts.dateFormat('%Y-%m-%d', this.value);
                                    }
                                }
                            },

                            yAxis: [{
                                    labels: {
                                        format: '{value}',
                                        style: {
                                            color: Highcharts.getOptions().colors[0]
                                        }
                                    },
                                    title: {
                                        text: index_name[0], // Corrected to index_name[0]
                                        style: {
                                            color: Highcharts.getOptions().colors[0]
                                        }
                                    }
                                },
                                {
                                    labels: {
                                        format: '{value}',
                                        style: {
                                            color: Highcharts.getOptions().colors[1]
                                        }
                                    },
                                    title: {
                                        text: index_name[1], // Corrected to index_name[1]
                                        style: {
                                            color: Highcharts.getOptions().colors[1]
                                        }
                                    },
                                    opposite: true
                                }
                            ],
                            time: {
                                useUTC: false
                            },

                            plotOptions: {
                                column: {
                                    pointPadding: 0.2,
                                    borderWidth: 0
                                }
                            },

                            legend: {
                                title: {
                                    text: ''
                                }
                            },

                            series: [{
                                    yAxis: 0,
                                    name: index_name[0], // Corrected to index_name[0]
                                    marker: {
                                        enabled: true,
                                        symbol: 'circle'
                                    },
                                    data: (function() {
                                        return graph_data_date[index_name[0]].map(function(date,
                                            i) {
                                            return [date, graph_data_value[index_name[
                                                0]][i]]; // Directly use date
                                        });
                                    })(),
                                    /*data: (function() {
                                        return graph_data_date.map(function(date,
                                            i) {
                                            return [date, graph_data_value[index_name[
                                                0]][i]]; // Directly use date
                                        });
                                    })(),*/
                                    color: 'red',
                                    lineWidth: 1
                                },
                                {
                                    name: index_name[1], // Corrected to index_name[1]
                                    yAxis: 1,
                                    marker: {
                                        enabled: true,
                                        symbol: 'circle'
                                    },
                                    data: (function() {
                                        return graph_data_date[index_name[1]].map(function(date,
                                            i) {
                                            return [date, graph_data_value[index_name[
                                                1]][i]]; // Directly use date
                                        });
                                    })(),
                                    color: 'blue',
                                    lineWidth: 1
                                }
                            ]
                        });

                    } catch (error) {
                        console.error('Error parsing or processing data:', error);
                    }
                } else {
                    console.error(`No data found for ${graphId}.`);
                }

                $('.highcharts-credits').hide();
            }

            // Example usage
            initializeChart('indices_graph_1', 'chartContainer_1');
            initializeChart('indices_graph_2', 'chartContainer_2');
            initializeChart('indices_graph_3', 'chartContainer_3');
            initializeChart('indices_graph_4', 'chartContainer_4');
            initializeChart('indices_graph_5', 'chartContainer_5');
            initializeChart('indices_graph_6', 'chartContainer_6');
            // Repeat for other charts as needed
        });
    </script>
    <style type="text/css">
    
.highcharts-label.highcharts-series-label{
    display: none;
}

.share_pdf {
    position: static;
    right: 0;
    top: -38px;
    display: flex;
    align-items: center;
    gap: 10px;
    justify-content: end;
    padding-bottom: 10px;
}

</style>
@endsection

@extends('web.layout.app')
@section('vue-js') @stop
@section('captcha') @stop
@if (isset($dataArr['meta_title']))
@section('page-title'){{ $dataArr['meta_title'] }}@stop
@else
@section('page-title'){{ $dataArr['title'] }}@stop
@endif
@if (isset($dataArr['meta_key']))
@section('meta-keywords'){{ $dataArr['meta_key'] }}@stop
@endif
@if (isset($dataArr['meta_descp']))
@section('meta-description'){{ $dataArr['meta_descp'] }}@stop
@endif
@if (isset($dataArr['image_path']))
@section('meta-image'){{ $dataArr['image_path'] }}@stop
@endif
@if ($dataArr['full_url'])
@section('cur-url'){{ $dataArr['full_url'] }}@stop
@endif
@section('content')
<section class="inner_banner_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner_section_banner">
                    <h4>{{$dataArr['title']}}</h4>
                </div>
            </div>
        </div>
    </div>
</section> 
<section  class="info_monitor_sec fund_watch_setion_home nfo_monitor_home_section section">
    <div class="container">
        @if(count($dataListModel) == 0)
            <p>{{ __('message.data_not_available') }}</p>
        @else
            @if($reqYear > 0)
                <div class="pentatech_filter_title m-3">
					<h4>{{ $singleArchieve[0]->year.' ('.$singleArchieve[0]->tot.')'}}</h4>
                </div>
                <div class="archive-wrapper">
                    <div class="archives-posts ">
                        <div class="row m-0 archive-row ">
                            @foreach($dataListModel as $key => $record)
                                <div class="archive-block col-md-6 col-lg-4">
                                    <div class="blog-sidebar-links blog-sidebar-block archieves-de br-5 box-shadow2">
                                        <x-link url="{{ route('web.nfomonitor', $record['no_id']) }}">{{ $record['fund_name'] }}</x-link>
                                        @if($record['objective'] != '')
                                            <p>{!! \App\Lib\Core\Useful::getShortContent(strip_tags($record['objective']), 80) !!}</p>
                                        @endif
                                        <h6>Posted On <span class="archive-post-date">{{ date($dateFormat, strtotime($record['post_date'])) }}</span></h6>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @else
                @foreach($dataListModel as $key => $record)
                <div class="archive-wrapper">
                    <div class="row m-0 justify-content-between align-items-center">
                        <div class="archive-title"><h3>{{ $key == 0 ? 'Recent NFO' : 'Archives From '.$record['archive']['year'] }} <span class="posts-count">({{ $record['archive']['tot'] }})</span></h3></div>
                        <div class="archive-view-all">
                            {{-- <x-link url="{{ route('web.nfomonitor.list', $record['archive']['year']) }}">View All</x-link> --}}
                        </div>
                    </div>
                    <div class="archives-posts">
                        <div class="row m-0 archive-row">
                            @if(count($record['items']) == 0)
                                <p>{{ __('message.data_not_available') }}</p>
                            @else
                           
                                @foreach($record['items'] as $key => $record2)
                                <div class="col-md-6 col-lg-4">
                                    <div class="single_blog">
                                        <div class="blog_content">
                                            <h4><a href="{{ route('web.nfomonitor', $record2['no_id']) }}">{{ $record2['fund_name'] }}</a></h4>
                                            @if($record2['objective'] != '')
                                            <p>{!! \App\Lib\Core\Useful::getShortContent(strip_tags($record2['objective']), 150) !!}</p>
                                        @endif
                                            <div class="post_author d-flex align-items-enter">
                                                <div class="post_admin d-flex align-items-enter"><i class="ph-user-light"></i> {{$record2['fund_manager'] ? $record2['fund_manager'] : ''}}</div>
                                                <div class="posted_date d-flex align-items-enter"><i class="ph-calendar-blank-light"></i> {{ date($dateFormat, strtotime($record2['post_date'])) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    @endforeach
                            @endif
                        </div>
                    </div>
                </div>
                @endforeach
            @endif
        @endif
    </div>
</section>
@stop